# Backgammon — Paul's game

A digital backgammon game: play **against the device**, as **white or
black** (your choice), under traditional rules, with **no doubling
cube**, for **Android, iOS, Windows and macOS**.

Version **1.2.3+4** · Dart / Flutter · No PHP anywhere.

## Layout

| Folder | What it is |
|---|---|
| `engine/` | Pure Dart game engine: board, legal moves, dice, computer opponent, match scoring, version. Shared identically by every platform. |
| `engine/bin/play.dart` | A complete, playable console version — the engine's testbed. |
| `app/` | The Flutter app (screen layer). Builds all four platforms from this one codebase. |

## Play the console version now

```sh
cd engine
dart run bin/play.dart                      # you are White; device is Black
dart run bin/play.dart --color black        # play as Black
dart run bin/play.dart --target 3           # match to 3 points instead of 5
dart run bin/play.dart --lat 39.74 --lon -104.99   # stand-in GPS fix for the dice seed
dart run bin/play.dart --difficulty hard    # easy | medium (default) | hard
dart run bin/play.dart --demo               # computer plays both sides
dart run test/engine_check.dart             # run the engine's checks
dart run tool/duel_check.dart               # strength check: Hard vs Easy, 12 games
dart compile exe bin/play.dart -o build/backgammon_console   # native binary
```

The dice are seeded per roll with the device clock-time and GPS
coordinates when available (here: `--lat/--lon` simulate a fix),
falling back step by step when they are not — each roll in the
console game prints which seed factors it actually used. On a real
device the app requests location permission and supplies a live fix
the same way. Time and GPS are always mixed with the operating
system's secure random source so the dice cannot be predicted from
the time and place of a roll.

## Run / build the app

You need the [Flutter SDK](https://docs.flutter.dev/get-started/install).
One codebase, four builds — with Apple's platform rule that iOS and
macOS builds are made on a Mac with Xcode:

```sh
cd app
flutter create .          # generate the android/ ios/ windows/ macos/ runners
flutter run               # run on a connected device or emulator
flutter build appbundle   # Android (Google Play)
flutter build ios         # iOS (on a Mac)
flutter build windows     # Windows (on Windows, with VS C++ tools)
flutter build macos       # macOS (on a Mac)
```

For release builds, add obfuscation:
`flutter build appbundle --obfuscate --split-debug-info=build/symbols`

## Change the version

Current version lives in `engine/lib/src/version.dart` and in both
`pubspec.yaml` files as `1.2.3+4` (version + build). Keep them in
sync with one command:

```sh
cd engine
dart run tool/bump_version.dart patch   # 1.0.0 -> 1.0.1  (fixes)
dart run tool/bump_version.dart minor   # 1.0.0 -> 1.1.0  (new features)
dart run tool/bump_version.dart major   # 1.0.0 -> 2.0.0  (big changes)
dart run tool/bump_version.dart build   # build number +1 only
```

## The board (app)

A drawn board with triangular points and round checkers, a centre
bar and borne-off trays. On your turn, **drag a checker** to its
destination — the points it may legally reach light up — or
**tap a checker, then tap its destination**. Moves are committed
one at a time through the engine's `TurnBuilder`, which filters
each step against the surviving legal plays, so a move the rules
would forbid finishing can never be started; an **Undo move**
button takes back a step within your turn. Points holding more
than five checkers show a count badge on the top checker.

## Difficulty levels

Chosen on the app's start screen, or with `--difficulty` on the
console. **Easy** picks a legal play at random — always
rules-correct, no plan; a relaxed learning game. **Medium** (the
default) is the one-move-ahead heuristic player. **Hard** adds
lookahead: each candidate play is also judged by the opponent's
best reply, averaged over all 21 possible reply rolls, so it
leaves fewer shots and sets up hits earlier. In the bundled
strength check (Hard vs Easy over 12 games, alternating colours)
Hard won **12–0**. When a roll offers more than 60 legal plays
(some doubles), Hard falls back to the Medium ranking for that
turn to stay responsive.

## Rules & scoring in this implementation

Standard setup (2/5/3/5), hitting blots, the bar and re-entry,
blocked points, doubles played four times, "use as many numbers as
possible" and the higher-die rule, bearing off from the home board.
Scoring, with no doubling cube: **single game 1 point, gammon 2,
backgammon 3**. A match runs to a target — default **first to 5**
(the popular apps offer 3, 5, 7 or 11).

Full rationale, including the dice-seed design, anti-piracy and
anti-tampering notes, is in the project specification in the goal's
documents (`backgammon-project-spec.md`).
