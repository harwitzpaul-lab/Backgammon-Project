# Getting the graphical Backgammon from GitHub — Paul's guide

Why: the drawn-board (graphical) edition of the game can only be
compiled on a Windows machine. GitHub provides Windows build
machines for free ("GitHub Actions"). The project already
contains the automatic build instructions — this guide is the
one-time setup to switch it on. After that, every build is:
open the Actions page, press "Run workflow", download the game.

Everything below is free. Nothing about the game changes; this
only adds a place where it gets built.

## One-time setup (about 15 minutes)

1. **GitHub account.** If you don't have one, sign up at
   github.com (free).
2. **Get the project onto your computer.** Unzip the latest
   source package Muse sent you (`backgammon-game-v1.2.3.zip`)
   into a folder you will keep, e.g. `Documents\backgammon-game`.
3. **Install GitHub Desktop** from desktop.github.com (free,
   made by GitHub for exactly this) and sign in with your
   GitHub account.
4. **Publish the project.** In GitHub Desktop:
   - File → "Add local repository…" → choose the
     `backgammon-game` folder → if it says the folder is not a
     repository, click "create a repository" and accept the
     defaults.
   - Click **"Publish repository"**. Public or private both
     work: public repositories get unlimited free build
     minutes; private ones include a free monthly allowance
     that covers occasional builds. (The game is meant to be
     distributed free anyway — your choice.)

## Every build after that

1. Go to your repository on github.com → the **Actions** tab.
2. In the left list, click **"Release installers"**, then
   **"Run workflow"** → "Run workflow".
3. Wait for the run to finish (roughly 10–15 minutes; the
   Windows job is the one you want).
4. Open the finished run and scroll to **Artifacts** at the
   bottom. Download **windows**. Inside are up to three files:
   - **Backgammon-Windows-App-1.2.3.zip** — the graphical game
     itself. Unzip it anywhere and double-click
     `backgammon_game.exe`. (It's not the Store build, so
     Windows may show the one-time SmartScreen prompt: "More
     info" → "Run anyway". McAfee may scan it on first run —
     that's normal.)
   - **Backgammon-Setup-1.2.3.exe** — the same game wrapped in
     a classic Windows installer (Start Menu shortcut,
     uninstaller).
   - **backgammon_game.msix** — the Microsoft Store package.
     It becomes the real, submittable Store package once the
     Partner Center identity values are in (the separate
     Partner Center step); until then treat it as a build test.
5. The same run also builds the Android, macOS and iOS packages
   (the other artifacts on the page) — the Mac and phone
   editions come from the same button press.

## Bonus: the privacy policy page (for the Store submission)

The Microsoft Store submission needs a public web address for
the privacy policy. Your repository can serve it for free: the
project includes a ready-made page at `docs/privacy-policy.html`.
Once the repository is published, on github.com go to the
repository's **Settings → Pages**, choose "Deploy from a
branch", branch **main**, folder **/docs**, and save. After a
minute the policy is live at an address like:

`https://<your-username>.github.io/<repository>/privacy-policy.html`

That is the address to paste into Partner Center. (The page
still has placeholders for your contact email and the effective
date — tell Muse both whenever you're ready and the page will
be updated.)

## Later, for new versions

When Muse sends you a newer source package, unzip it over the
same folder (replace the files), then in GitHub Desktop write a
short summary (e.g. "Version 1.2.4"), click **Commit to main**,
then **Push origin**. Pushing a version tag (Muse will give
you the exact step when it's time) also attaches the installers
to a GitHub Release page automatically.

## Notes

- The text (console) edition in `dist\` downloads Muse sends
  you directly is unaffected — this is an additional route, for
  the graphical edition.
- If a build ever fails, open the failed run, click the red
  job, and send Muse a screenshot of the red step — the log
  will say exactly what to fix.
