// Backgammon — Windows console edition (v1.2.3).
//
// A faithful C++ port of the Dart engine in ../engine (same board
// model, same legal-move rules, same AI evaluation weights, same
// dice seeding design), built so a real Windows .exe can be
// produced by cross-compiling from Linux with MinGW-w64:
//
//   x86_64-w64-mingw32-g++-win32 -O2 -static -std=c++17 -s
//       -o Backgammon-Windows-v1.2.3.exe backgammon.cpp resources.o
//       -luser32
//
// v1.2.3: Paul's screenshot of v1.2.1 in play revealed the real
// problem all along — the program WAS running (and his McAfee
// logs agreed it was never blocked); it was waiting at the
// "Choose a move number" prompt, but the long single-column
// move list had pushed the board and instructions off the top
// of the window, so the screen looked like raw code and the
// game looked hung. Fixes: a how-to-play screen with a
// press-Enter start, the screen cleared each turn so board,
// dice and moves stay together, and the move list printed in
// two columns.
//
// v1.2.2: when the human's roll leaves no legal move, a Windows
// message box ("No further moves available", single OK button)
// must be acknowledged before the device takes its turn — hence
// the user32 link. The opening banner carries the full copyright
// and free-distribution notices.
//
// v1.2.1 Windows 11 fix: v1.2.0 ran fine under emulation (Wine:
// self-test, demo and interactive all pass), but as shipped it was
// a bare, unsigned MinGW binary — no application manifest, no
// version resource, full debug symbols, and the POSIX-thread
// runtime statically linked — exactly the profile Windows 11's
// SmartScreen / Smart App Control and Defender block or flag on a
// downloaded program. The 1.2.1 build uses the win32-thread
// compiler (no winpthread layer; this program starts no threads),
// is stripped, and embeds a proper manifest (declares Windows
// 10/11 support) and VERSIONINFO (see resources.rc).
//
// Traditional rules, white vs black, NO doubling cube. Dice are
// seeded per roll with the device clock-time and GPS coordinates
// (supplied with --lat/--lon, standing in for a live fix) mixed
// with OS entropy (std::random_device), so rolls cannot be
// predicted from time and place alone — the same refinement as
// the Dart engine. Without --lat/--lon the GPS factor drops out
// and the remaining factors carry the roll, per Paul's spec.
//
// Play:
//   Backgammon-Windows-v1.2.3.exe [--color white|black]
//       [--target 5] [--difficulty easy|medium|hard]
//       [--lat 39.74 --lon -104.99] [--demo] [--selftest]

#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <optional>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <io.h>       // _isatty, _fileno
#include <windows.h>  // MessageBoxA, for the no-moves alert
#else
#include <unistd.h>  // isatty
#endif

static const char* kVersion = "1.2.3+6";

// True when stdin is a real terminal (a double-clicked console
// window), false when input is piped (tests, scripts). The
// screen-clearing and press-Enter touches apply only to the
// real-terminal case.
static bool interactiveConsole() {
#ifdef _WIN32
  return _isatty(_fileno(stdin)) != 0;
#else
  return isatty(fileno(stdin)) != 0;
#endif
}

// Clear the screen (ANSI) so each turn — board, dice, move list
// and prompt — appears together on one screen instead of the
// board scrolling away above a long list.
static void clearScreen() {
  std::cout << "\033[2J\033[H" << std::flush;
}

// ---------------------------------------------------------------- board

enum class Checker { White, Black };

static Checker opponentOf(Checker c) {
  return c == Checker::White ? Checker::Black : Checker::White;
}
static int signOf(Checker c) { return c == Checker::White ? 1 : -1; }
static const char* labelOf(Checker c) {
  return c == Checker::White ? "White" : "Black";
}

static const int BAR_FROM = -1;  // a move that starts on the bar
static const int OFF_TO = -2;    // a move that bears a checker off

struct Move {
  int from, to, die;
  bool hits = false;

  // Traditional notation from the moving player's point of view.
  std::string describe(Checker player) const {
    auto name = [&](int idx, bool isFrom) {
      if (isFrom && idx == BAR_FROM) return std::string("bar");
      if (!isFrom && idx == OFF_TO) return std::string("off");
      return std::to_string(player == Checker::White ? idx + 1 : 24 - idx);
    };
    return name(from, true) + "/" + name(to, false) + (hits ? "*" : "");
  }
  std::string key() const {
    return std::to_string(from) + ">" + std::to_string(to) + "," +
           std::to_string(die) + (hits ? "h" : "");
  }
};

struct Board {
  std::array<int, 24> p{};
  int whiteBar = 0, blackBar = 0, whiteOff = 0, blackOff = 0;

  static Board initial() {
    Board b;
    auto place = [&](Checker c, int traditionalPoint, int count) {
      int idx = (c == Checker::White) ? traditionalPoint - 1
                                      : 24 - traditionalPoint;
      b.p[idx] = count * signOf(c);
    };
    for (Checker c : {Checker::White, Checker::Black}) {
      place(c, 24, 2);
      place(c, 13, 5);
      place(c, 8, 3);
      place(c, 6, 5);
    }
    return b;
  }

  int countFor(Checker c, int idx) const {
    int v = p[idx];
    return c == Checker::White ? (v > 0 ? v : 0) : (v < 0 ? -v : 0);
  }
  int barFor(Checker c) const {
    return c == Checker::White ? whiteBar : blackBar;
  }
  int offFor(Checker c) const {
    return c == Checker::White ? whiteOff : blackOff;
  }
  int totalFor(Checker c) const {
    int t = barFor(c) + offFor(c);
    for (int i = 0; i < 24; i++) t += countFor(c, i);
    return t;
  }
  int pipCount(Checker c) const {
    int pips = barFor(c) * 25;
    for (int i = 0; i < 24; i++) {
      int n = countFor(c, i);
      if (n) pips += n * (c == Checker::White ? i + 1 : 24 - i);
    }
    return pips;
  }
  bool isBlockedFor(Checker c, int idx) const {
    return countFor(opponentOf(c), idx) >= 2;
  }
  bool allInHome(Checker c) const {
    if (barFor(c) > 0) return false;
    if (c == Checker::White) {
      for (int i = 6; i < 24; i++)
        if (countFor(c, i) > 0) return false;
    } else {
      for (int i = 0; i < 18; i++)
        if (countFor(c, i) > 0) return false;
    }
    return true;
  }
  bool isGameOver() const { return whiteOff == 15 || blackOff == 15; }
  std::optional<Checker> winner() const {
    if (whiteOff == 15) return Checker::White;
    if (blackOff == 15) return Checker::Black;
    return std::nullopt;
  }

  Board after(const Move& m, Checker c) const {
    Board b = *this;
    if (m.from == BAR_FROM) {
      if (c == Checker::White) b.whiteBar--; else b.blackBar--;
    } else {
      b.p[m.from] -= signOf(c);
    }
    if (m.to == OFF_TO) {
      if (c == Checker::White) b.whiteOff++; else b.blackOff++;
    } else {
      if (m.hits) {
        b.p[m.to] = 0;
        if (opponentOf(c) == Checker::White) b.whiteBar++; else b.blackBar++;
      }
      b.p[m.to] += signOf(c);
    }
    return b;
  }

  bool anyOn(Checker c, int fromIdx, int toIdx) const {
    if (fromIdx > toIdx) return false;
    for (int i = fromIdx; i <= toIdx; i++)
      if (countFor(c, i) > 0) return true;
    return false;
  }

  std::vector<Move> singleMoves(Checker c, int die) const {
    std::vector<Move> moves;
    auto tryLand = [&](int from, int to) {
      if (isBlockedFor(c, to)) return;
      moves.push_back({from, to, die, countFor(opponentOf(c), to) == 1});
    };
    if (barFor(c) > 0) {
      int entry = (c == Checker::White) ? 24 - die : die - 1;
      tryLand(BAR_FROM, entry);
      return moves;
    }
    bool canBearOff = allInHome(c);
    for (int i = 0; i < 24; i++) {
      if (countFor(c, i) == 0) continue;
      if (c == Checker::White) {
        int dest = i - die;
        if (dest >= 0) {
          tryLand(i, dest);
        } else if (canBearOff) {
          bool exact = dest == -1;
          bool higherWithNoneBeyond = dest < -1 && !anyOn(c, i + 1, 5);
          if (exact || higherWithNoneBeyond)
            moves.push_back({i, OFF_TO, die, false});
        }
      } else {
        int dest = i + die;
        if (dest <= 23) {
          tryLand(i, dest);
        } else if (canBearOff) {
          bool exact = dest == 24;
          bool higherWithNoneBeyond = dest > 24 && !anyOn(c, 18, i - 1);
          if (exact || higherWithNoneBeyond)
            moves.push_back({i, OFF_TO, die, false});
        }
      }
    }
    return moves;
  }

  // All complete, rule-legal ways to play a roll: doubles x4, must
  // use as many numbers as possible, higher die forced when only
  // one of two different numbers can be played.
  std::vector<std::vector<Move>> legalSequencesFor(Checker c,
                                                   std::vector<int> dice) {
    std::vector<int> rolls =
        (dice[0] == dice[1])
            ? std::vector<int>{dice[0], dice[0], dice[0], dice[0]}
            : dice;
    std::vector<std::vector<Move>> results;
    std::vector<Move> soFar;
    dfs(*this, c, rolls, soFar, results);
    if (results.empty()) return {};
    size_t maxLen = 0;
    for (auto& s : results) maxLen = std::max(maxLen, s.size());
    std::vector<std::vector<Move>> best;
    for (auto& s : results)
      if (s.size() == maxLen) best.push_back(s);

    if (dice[0] != dice[1] && maxLen == 1 && !best.empty()) {
      std::set<int> used;
      for (auto& s : best) used.insert(s.front().die);
      if (used.size() > 1) {
        int high = std::max(dice[0], dice[1]);
        std::vector<std::vector<Move>> filtered;
        for (auto& s : best)
          if (s.front().die == high) filtered.push_back(s);
        best = filtered;
      }
    }
    std::set<std::string> seen;
    std::vector<std::vector<Move>> out;
    for (auto& s : best) {
      std::string k;
      for (auto& m : s) k += m.key() + ";";
      if (seen.insert(k).second) out.push_back(s);
    }
    return out;
  }

  static void dfs(Board b, Checker c, std::vector<int> remaining,
                  std::vector<Move>& soFar,
                  std::vector<std::vector<Move>>& results) {
    if (remaining.empty()) {
      results.push_back(soFar);
      return;
    }
    bool moved = false;
    std::set<int> tried;
    for (size_t ri = 0; ri < remaining.size(); ri++) {
      int die = remaining[ri];
      if (!tried.insert(die).second) continue;
      for (const Move& m : b.singleMoves(c, die)) {
        moved = true;
        std::vector<int> next = remaining;
        next.erase(next.begin() + (long)ri);
        soFar.push_back(m);
        dfs(b.after(m, c), c, next, soFar, results);
        soFar.pop_back();
      }
    }
    if (!moved) results.push_back(soFar);
  }

  // Single game 1, gammon 2, backgammon 3 (no doubling cube).
  int gamePoints(Checker w) const {
    Checker loser = opponentOf(w);
    if (offFor(loser) > 0) return 1;
    bool onBar = barFor(loser) > 0;
    bool inWinnerHome = false;
    if (w == Checker::White) {
      for (int i = 0; i <= 5; i++)
        if (countFor(loser, i) > 0) inWinnerHome = true;
    } else {
      for (int i = 18; i <= 23; i++)
        if (countFor(loser, i) > 0) inWinnerHome = true;
    }
    return (onBar || inWinnerHome) ? 3 : 2;
  }

  std::string render() const {
    auto cell = [&](int idx) {
      int v = p[idx];
      if (v == 0) return std::string("  . ");
      std::string s = std::string(" ") + (v > 0 ? 'W' : 'B') +
                      std::to_string(std::abs(v)) + " ";
      while (s.size() < 4) s += " ";
      return s.substr(0, 4);
    };
    std::ostringstream os;
    os << " 13-24: ";
    for (int i = 12; i < 24; i++) os << cell(i);
    os << "\n  12-1: ";
    for (int i = 11; i >= 0; i--) os << cell(i);
    os << "\n Bar: W" << whiteBar << " B" << blackBar << "   Off: W"
       << whiteOff << " B" << blackOff << "   Pips: W"
       << pipCount(Checker::White) << " B" << pipCount(Checker::Black);
    return os.str();
  }
};

// ----------------------------------------------------------------- dice

struct GpsFix {
  double latitude, longitude;
};

struct DiceRoll {
  int die1, die2;
  std::string seedSource;
};

static uint64_t splitMix64(uint64_t x) {
  uint64_t z = x + 0x9E3779B97F4A7C15ULL;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
  return z ^ (z >> 31);
}

static uint64_t fnv1a64(const std::string& s) {
  uint64_t hash = 0xcbf29ce484222325ULL;
  for (unsigned char ch : s) {
    hash ^= ch;
    hash *= 0x100000001b3ULL;
  }
  return hash;
}

// Same seeding design as the Dart DiceRoller: clock-time and GPS
// are genuine factors whenever available, always mixed with OS
// entropy (std::random_device) so time+place alone cannot predict
// the dice.
struct DiceRoller {
  std::optional<GpsFix> fix;  // stands in for a live GPS fix
  uint64_t counter = 0;
  uint64_t state = 0;

  DiceRoll rollPair() {
    std::string source;
    int d1 = nextDie(source);
    std::string ignored;
    int d2 = nextDie(ignored);
    return {d1, d2, source};
  }
  int rollSingle() {
    std::string ignored;
    return nextDie(ignored);
  }

  int nextDie(std::string& sourceOut) {
    counter++;
    std::vector<std::string> factors;

    int64_t micros = std::chrono::duration_cast<std::chrono::microseconds>(
                         std::chrono::system_clock::now().time_since_epoch())
                         .count();
    factors.push_back("clock-time");
    if (fix) factors.push_back("GPS");

    std::optional<uint64_t> secureBits;
    bool secureFailed = false;
    try {
      std::random_device rd;
      secureBits = (uint64_t(rd()) << 32) | uint64_t(rd());
      factors.push_back("OS secure random");
    } catch (...) {
      secureFailed = true;
    }

    std::ostringstream entropy;
    entropy << micros << "|";
    if (fix) {
      char buf[64];
      std::snprintf(buf, sizeof buf, "%.6f,%.6f", fix->latitude,
                    fix->longitude);
      entropy << buf;
    } else {
      entropy << "nogps";
    }
    entropy << "|";
    if (secureBits) entropy << *secureBits; else entropy << "nosecure";
    entropy << "|" << counter;

    state = fnv1a64(entropy.str()) ^ splitMix64(counter * 7919 + 13);
    state = splitMix64(state);

    if (secureFailed && factors.empty()) {
      sourceOut = "last-resort fallback random";
    } else if (factors.size() == 1 && factors[0] == "OS secure random") {
      sourceOut = "OS secure random (fallback: no clock-time, no GPS)";
    } else {
      std::string joined;
      for (size_t i = 0; i < factors.size(); i++) {
        if (i) joined += " + ";
        joined += factors[i];
      }
      sourceOut = joined;
    }
    return dieFrom(state);
  }

  int dieFrom(uint64_t value) {
    uint64_t v = value & 0x7FFFFFFFFFFFFFFFULL;
    const uint64_t limit = 9223372036854775806ULL;  // 2^63-2, divisible by 6
    while (v >= limit) {
      state = splitMix64(state + 1);
      v = state & 0x7FFFFFFFFFFFFFFFULL;
    }
    return int(v % 6) + 1;
  }
};

// ------------------------------------------------------------------- ai

enum class Difficulty { Easy, Medium, Hard };

static const char* labelOf(Difficulty d) {
  return d == Difficulty::Easy ? "Easy" : d == Difficulty::Medium ? "Medium"
                                                                   : "Hard";
}

// Seed for the AI's random choices. Guarded: if the OS entropy
// source ever fails at start-up, fall back to the clock rather
// than letting an exception kill the program before it opens.
static uint64_t safeSeed() {
  try {
    return std::random_device{}();
  } catch (...) {
    return (uint64_t)std::chrono::duration_cast<std::chrono::microseconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
  }
}

struct ComputerPlayer {
  Difficulty difficulty = Difficulty::Medium;
  std::mt19937_64 rng{safeSeed()};
  static const int kHardLookaheadCap = 60;

  std::vector<Move> choose(Board b, Checker c, std::vector<int> dice) {
    auto options = b.legalSequencesFor(c, dice);
    if (options.empty()) return {};
    if (difficulty == Difficulty::Easy) {
      return options[rng() % options.size()];
    }
    bool lookahead =
        difficulty == Difficulty::Hard &&
        (int)options.size() <= kHardLookaheadCap;
    std::vector<Move> best;
    double bestScore = -1e100;
    for (auto& seq : options) {
      Board after = apply(b, c, seq);
      double s = lookahead ? lookaheadScore(after, c) : evaluate(after, c);
      if (s > bestScore) {
        bestScore = s;
        best = seq;
      }
    }
    return best;
  }

  static Board apply(Board b, Checker c, const std::vector<Move>& seq) {
    for (auto& m : seq) b = b.after(m, c);
    return b;
  }

  double lookaheadScore(Board after, Checker c) const {
    if (after.isGameOver()) return 10000 + evaluate(after, c);
    Checker opp = opponentOf(c);
    double total = 0.0;
    for (int d1 = 1; d1 <= 6; d1++) {
      for (int d2 = d1; d2 <= 6; d2++) {
        double weight = d1 == d2 ? 1 : 2;
        auto replies = after.legalSequencesFor(opp, {d1, d2});
        double replyBest = -1e100;
        Board replyBoard = after;
        for (auto& seq : replies) {
          Board end = apply(after, opp, seq);
          double s = evaluate(end, opp);
          if (s > replyBest) {
            replyBest = s;
            replyBoard = end;
          }
        }
        total += weight * evaluate(replyBoard, c);
      }
    }
    return total / 36.0;
  }

  // Same weights as the Dart engine's evaluate().
  static double evaluate(const Board& b, Checker c) {
    Checker opp = opponentOf(c);
    double score = 0.0;
    score += (b.pipCount(opp) - b.pipCount(c)) * 1.0;
    score += (b.offFor(c) - b.offFor(opp)) * 18.0;
    score += (b.barFor(opp) - b.barFor(c)) * 22.0;
    auto inHome = [](int idx, Checker who) {
      return who == Checker::White ? idx <= 5 : idx >= 18;
    };
    for (int i = 0; i < 24; i++) {
      int mine = b.countFor(c, i);
      int theirs = b.countFor(opp, i);
      if (mine >= 2) {
        score += 4;
        if (inHome(i, c) || inHome(i, opp)) score += 3;
      } else if (mine == 1) {
        score -= inHome(i, c) ? 5 : 3;
      }
      if (theirs >= 2) {
        score -= 4;
        if (inHome(i, opp) || inHome(i, c)) score -= 3;
      } else if (theirs == 1) {
        score += 2;
      }
    }
    return score;
  }
};

// ---------------------------------------------------------------- match

struct Match {
  int targetPoints = 5;
  int whiteScore = 0, blackScore = 0;
  int gamesPlayed = 0, humanWins = 0, deviceWins = 0;

  void recordGame(Checker winner, Checker human, int points) {
    gamesPlayed++;
    if (winner == Checker::White) whiteScore += points; else blackScore += points;
    if (winner == human) humanWins++; else deviceWins++;
  }
  bool isOver() const {
    return whiteScore >= targetPoints || blackScore >= targetPoints;
  }
  std::string summary(Checker human) const {
    std::ostringstream os;
    os << "Games played: " << gamesPlayed << " (you won " << humanWins
       << ", device won " << deviceWins << ") — match score: you "
       << (human == Checker::White ? whiteScore : blackScore) << ", device "
       << (human == Checker::White ? blackScore : whiteScore) << " (first to "
       << targetPoints << ")";
    if (isOver()) {
      int hs = human == Checker::White ? whiteScore : blackScore;
      int ds = human == Checker::White ? blackScore : whiteScore;
      os << (hs > ds ? " — you win the match!" : " — the device wins the match.");
    }
    return os.str();
  }
};

// ------------------------------------------------------------- selftest

static int g_failures = 0;
static void check(bool ok, const std::string& what) {
  std::cout << (ok ? "  ok  " : "  XX  ") << what << "\n";
  if (!ok) g_failures++;
}

static int runSelftest() {
  Board b = Board::initial();
  check(b.totalFor(Checker::White) == 15 && b.totalFor(Checker::Black) == 15,
        "Initial position: 15 checkers per side");
  check(b.pipCount(Checker::White) == 167 && b.pipCount(Checker::Black) == 167,
        "Initial pip counts are 167 each");
  check(b.p[23] == 2 && b.p[12] == 5 && b.p[7] == 3 && b.p[5] == 5,
        "White setup is 2/5/3/5 on the 24/13/8/6 points");

  auto opening = b.legalSequencesFor(Checker::White, {3, 1});
  bool allTwo = !opening.empty();
  for (auto& s : opening) allTwo = allTwo && s.size() == 2;
  check(allTwo, "Opening 3-1 always uses both dice");

  auto doubles = b.legalSequencesFor(Checker::White, {6, 6});
  bool allFour = !doubles.empty();
  for (auto& s : doubles) allFour = allFour && s.size() == 4;
  check(allFour, "Doubles are played four times");

  // Hitting: white blot on index 9 (white's view), black lands on it.
  Board hit;
  hit.p = {};
  hit.p[9] = 1;   // white blot
  hit.p[7] = -1;  // black checker two below it (black moves up in index)
  hit.blackOff = 14;
  hit.whiteOff = 14;
  auto hitSeqs = hit.legalSequencesFor(Checker::Black, {2, 3});
  bool foundHit = false;
  for (auto& s : hitSeqs)
    for (auto& m : s)
      if (m.hits && m.to == 9) foundHit = true;
  check(foundHit, "A blot can be hit");
  Board afterHit = hit;
  for (auto& s : hitSeqs) {
    bool doesHit = false;
    for (auto& m : s) doesHit = doesHit || (m.hits && m.to == 9);
    if (doesHit) {
      afterHit = ComputerPlayer::apply(hit, Checker::Black, s);
      break;
    }
  }
  check(afterHit.whiteBar == 1, "A hit checker goes to the bar");

  // Blocked bar entry: white on the bar, black holds all entry points.
  Board blocked;
  blocked.p = {};
  blocked.whiteBar = 1;
  blocked.whiteOff = 14;
  blocked.blackOff = 9;
  for (int i = 18; i <= 23; i++) blocked.p[i] = -2;
  blocked.p[0] = -3;
  auto none = blocked.legalSequencesFor(Checker::White, {3, 4});
  check(none.size() == 1 && none[0].empty(),
        "Fully blocked bar entry means no move");

  // Bearing off with a higher die than the exact point.
  Board bear;
  bear.p = {};
  bear.p[2] = 1;  // white checker on the 3-point
  bear.whiteOff = 14;
  bear.blackOff = 15 - 0;  // black still racing; give black 15 on board far away
  bear.blackOff = 0;
  bear.p[20] = -15;
  auto bearSeqs = bear.legalSequencesFor(Checker::White, {6, 1});
  bool canBear = false;
  for (auto& s : bearSeqs)
    for (auto& m : s)
      if (m.to == OFF_TO) canBear = true;
  check(canBear, "Higher die may bear off the highest checker");

  // Scoring: gammon and backgammon.
  Board gam;
  gam.p = {};
  gam.whiteOff = 15;
  gam.p[20] = -15;
  check(gam.gamePoints(Checker::White) == 2, "Gammon scores 2");
  gam.blackBar = 1;
  gam.p[20] = -14;
  check(gam.gamePoints(Checker::White) == 3, "Backgammon scores 3");

  // Dice: faces stay in range.
  DiceRoller roller;
  bool inRange = true;
  for (int i = 0; i < 600; i++) {
    int d = roller.rollSingle();
    if (d < 1 || d > 6) inRange = false;
  }
  check(inRange, "600 rolls all land in 1..6");

  // AI returns a legal sequence.
  ComputerPlayer ai;
  ai.difficulty = Difficulty::Hard;
  auto seq = ai.choose(Board::initial(), Checker::White, {3, 1});
  check(seq.size() == 2, "Hard AI plays a full legal sequence");

  std::cout << (g_failures == 0 ? "All self-test checks passed.\n"
                                : "SELF-TEST FAILURES\n");
  return g_failures == 0 ? 0 : 1;
}

// ----------------------------------------------------------------- game

static std::vector<Move> askHuman(Board& board, Checker turn,
                                  std::vector<std::vector<Move>>& sequences) {
  // Two columns (v1.2.3): a long single-column list pushed the
  // board off the top of the window and made the game look like
  // a screen of raw code.
  std::vector<std::string> entries;
  for (size_t i = 0; i < sequences.size(); i++) {
    std::ostringstream os;
    os << "[" << i << "] ";
    for (size_t j = 0; j < sequences[i].size(); j++) {
      if (j) os << ", ";
      os << sequences[i][j].describe(turn);
    }
    entries.push_back(os.str());
  }
  std::cout << "Your legal moves:\n";
  const size_t colWidth = 30;
  for (size_t i = 0; i < entries.size(); i += 2) {
    std::cout << "  " << entries[i];
    if (i + 1 < entries.size()) {
      size_t pad =
          entries[i].size() < colWidth ? colWidth - entries[i].size() : 2;
      std::cout << std::string(pad, ' ') << entries[i + 1];
    }
    std::cout << "\n";
  }
  while (true) {
    std::cout << "Choose a move number: " << std::flush;
    std::string line;
    if (!std::getline(std::cin, line)) return {};
    try {
      size_t pos;
      int n = std::stoi(line, &pos);
      if (n >= 0 && n < (int)sequences.size()) return sequences[n];
    } catch (...) {
    }
    std::cout << "Please enter a number from the list.\n";
  }
}

// Paul's requested alert (v1.2.2): when the human's roll leaves
// no legal move, show a "No further moves available" alert with
// a single OK button; the game proceeds to the device's turn
// only after the player acknowledges it. On Windows this is a
// real clickable message box; elsewhere it is a console prompt
// that waits for Enter.
static void showNoMovesAlert() {
#ifdef _WIN32
  MessageBoxA(nullptr, "No further moves available", "Backgammon",
              MB_OK | MB_ICONINFORMATION);
#else
  std::cout << "\n*** No further moves available ***\n"
               "Press Enter (OK) to continue...";
  std::string line;
  std::getline(std::cin, line);
#endif
}

static Checker playOneGame(DiceRoller& roller, ComputerPlayer& ai,
                           Checker human, bool demo, int& pointsOut) {
  Board board = Board::initial();
  Checker turn;
  std::vector<int> dice;
  int openW, openB;
  while (true) {
    int w = roller.rollSingle();
    int b = roller.rollSingle();
    if (w == b) continue;
    turn = w > b ? Checker::White : Checker::Black;
    dice = {w, b};
    openW = w;
    openB = b;
    break;
  }
  std::cout << "Opening roll: White " << openW << ", Black " << openB << " — "
            << labelOf(turn) << " opens with " << openW << "-" << openB
            << ".\n";

  while (!board.isGameOver()) {
    bool isHumanTurn = !demo && turn == human;
    if (!demo && interactiveConsole()) clearScreen();
    std::cout << "\n" << board.render() << "\n";
    std::cout << labelOf(turn) << " to move, rolled " << dice[0] << "-"
              << dice[1] << "\n";
    auto sequences = board.legalSequencesFor(turn, dice);
    std::vector<Move> chosen;
    if (sequences.empty() ||
        (sequences.size() == 1 && sequences[0].empty())) {
      if (isHumanTurn) {
        showNoMovesAlert();
      } else {
        std::cout << "No legal move — turn passes.\n";
      }
    } else if (isHumanTurn) {
      chosen = askHuman(board, turn, sequences);
    } else {
      chosen = ai.choose(board, turn, dice);
      std::cout << labelOf(turn) << " plays: ";
      for (size_t j = 0; j < chosen.size(); j++) {
        if (j) std::cout << ", ";
        std::cout << chosen[j].describe(turn);
      }
      std::cout << "\n";
    }
    for (auto& m : chosen) {
      board = board.after(m, turn);
      if (board.isGameOver()) break;
    }
    if (board.isGameOver()) break;
    turn = opponentOf(turn);
    DiceRoll roll = roller.rollPair();
    dice = {roll.die1, roll.die2};
    if (!demo) std::cout << "(dice seed: " << roll.seedSource << ")\n";
  }
  pointsOut = board.gamePoints(*board.winner());
  return *board.winner();
}

int main(int argc, char** argv) {
  bool demo = false, selftest = false;
  Checker human = Checker::White;
  int target = 5;
  Difficulty difficulty = Difficulty::Medium;
  std::optional<double> lat, lon;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    auto next = [&]() { return std::string(argv[++i]); };
    if (a == "--demo") demo = true;
    else if (a == "--selftest") selftest = true;
    else if (a == "--difficulty") {
      std::string v = next();
      if (v == "easy") difficulty = Difficulty::Easy;
      else if (v == "hard") difficulty = Difficulty::Hard;
      else difficulty = Difficulty::Medium;
    } else if (a == "--color") {
      human = next() == "black" ? Checker::Black : Checker::White;
    } else if (a == "--target") {
      target = std::stoi(next());
    } else if (a == "--lat") {
      lat = std::stod(next());
    } else if (a == "--lon") {
      lon = std::stod(next());
    }
  }

  if (selftest) return runSelftest();

#ifdef _WIN32
  // Let the classic Windows console understand the ANSI
  // clear-screen sequence (Windows Terminal already does).
  HANDLE outHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  DWORD outMode = 0;
  if (outHandle != INVALID_HANDLE_VALUE &&
      GetConsoleMode(outHandle, &outMode)) {
    SetConsoleMode(outHandle,
                   outMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
  }
#endif

  DiceRoller roller;
  if (lat && lon) roller.fix = GpsFix{*lat, *lon};
  ComputerPlayer ai;
  ai.difficulty = difficulty;
  Match match;
  match.targetPoints = demo ? 1 : target;

  std::cout << "Backgammon v" << kVersion << " — no doubling cube\n";
  std::cout << "© Paul Harwitz\n"
               "Authorized for totally free distribution and use "
               "only.\n"
               "All Rights Reserved.\n"
               "Tous Droits Réservés.\n"
               "Alle Rechte vorbehalten.\n";
  if (demo) {
    std::cout << "Demo game: the computer plays both sides.\n";
  } else {
    std::cout << "You are " << labelOf(human) << ". The device is "
              << labelOf(opponentOf(human)) << " (difficulty: "
              << labelOf(difficulty) << ").\n";
  }

  if (!demo && interactiveConsole()) {
    // How-to-play screen (v1.2.3): nothing in the earlier builds
    // told a double-clicking player what the numbered list was
    // or that the game was waiting for a typed move number.
    std::cout <<
        "\nThis is the text edition of the game. How to play:\n"
        "  - The board appears at the top of the screen each turn.\n"
        "  - On your turn, type the number of a move from the list\n"
        "    and press Enter. To quit, type q and press Enter at\n"
        "    the move prompt.\n"
        "  - If a roll leaves you no move, an alert appears;\n"
        "    acknowledge it and the device takes its turn.\n"
        "\nPress Enter to start playing...";
    std::string line;
    std::getline(std::cin, line);
  }

  while (!match.isOver()) {
    int points = 1;
    Checker winner = playOneGame(roller, ai, human, demo, points);
    match.recordGame(winner, human, points);
    std::cout << "Game over: " << labelOf(winner) << " wins, " << points
              << " point(s). " << match.summary(human) << "\n";
    if (demo) break;
    if (!match.isOver()) {
      std::cout << "Play another game? [y/N] " << std::flush;
      std::string a;
      if (!std::getline(std::cin, a) || a != "y") break;
    }
  }
  return 0;
}
