/// Dependency-free checks for the backgammon engine.
/// Run:  dart run test/engine_check.dart   (exits non-zero on failure)
import 'dart:io';
import 'dart:math';

import 'package:backgammon_engine/backgammon_engine.dart';

var _failures = 0;
void check(bool ok, String what) {
  if (ok) {
    stdout.writeln('  ok  $what');
  } else {
    _failures++;
    stderr.writeln('FAIL  $what');
  }
}

void main() {
  // --- Setup -------------------------------------------------------
  final start = Board.initial();
  check(start.totalFor(Checker.white) == 15, 'White starts with 15 checkers');
  check(start.totalFor(Checker.black) == 15, 'Black starts with 15 checkers');
  check(start.pipCount(Checker.white) == 167, 'White starting pip count is 167');
  check(start.pipCount(Checker.black) == 167, 'Black starting pip count is 167');

  // --- Opening move generation ------------------------------------
  final seqs31 = start.legalSequencesFor(Checker.white, [3, 1]);
  check(seqs31.isNotEmpty, 'White has legal plays for an opening 3-1');
  check(seqs31.every((s) => s.length == 2),
      'Opening 3-1 plays use both dice');

  final seqsDouble = start.legalSequencesFor(Checker.white, [6, 6]);
  check(seqsDouble.isNotEmpty && seqsDouble.every((s) => s.length == 4),
      'Doubles are played four times');

  // --- Hitting a blot ----------------------------------------------
  final hit = Board.empty();
  hit.points[10] = 1; // one White checker
  hit.points[7] = -1; // one Black blot in range of a 3
  final hitMoves = hit.singleMoves(Checker.white, 3);
  final theHit = hitMoves.where((m) => m.to == 7).toList();
  check(theHit.length == 1 && theHit.single.hits, 'Landing on a blot is a hit');
  final afterHit = hit.after(theHit.single, Checker.white);
  check(afterHit.blackBar == 1 && afterHit.countFor(Checker.black, 7) == 0,
      'A hit checker goes to the bar');

  // --- Bar re-entry -------------------------------------------------
  final bar = Board.empty();
  bar.blackBar = 1;
  bar.points[2] = 2; // White blocks the 3-entry point for Black
  final entries = bar.singleMoves(Checker.black, 4);
  check(entries.length == 1 && entries.single.from == barFrom,
      'A checker on the bar can only re-enter');
  check(bar.singleMoves(Checker.black, 3).isEmpty,
      'Re-entry onto a blocked point is illegal');

  // --- Bearing off ---------------------------------------------------
  final home = Board.empty();
  home.points[0] = 14; // 14 White checkers already context: use counts
  home.whiteOff = 0;
  home.points[0] = 1;
  home.points[2] = 1;
  // Exact bear-off from the 3-point with a 3:
  final exact = home.singleMoves(Checker.white, 3);
  check(exact.any((m) => m.from == 2 && m.to == offTo),
      'Exact die bears off');
  // A higher die may bear off the highest checker (on the 3-point)
  // when nothing sits on a higher point:
  final higher = home.singleMoves(Checker.white, 5);
  check(higher.any((m) => m.from == 2 && m.to == offTo),
      'Higher die bears off the highest checker when allowed');
  // ...but not a lower checker while a higher one remains:
  check(!higher.any((m) => m.from == 0 && m.to == offTo),
      'Higher die may not skip past a higher checker');

  // --- Must-use-higher-die rule -------------------------------------
  // White checker on index 10; Black blocks index 5 (so a 5 lands
  // blocked, a 2 is playable, and after the 2 the 5 is still blocked
  // from index 8): only one die is playable, both work alone -> 5? No:
  // construct per rule: if only one can be played it must be the higher
  // *playable* one. Here only the 2 is playable at all, so 2 is forced
  // trivially; verify sequences have length 1.
  final forced = Board.empty();
  forced.points[10] = 1;
  forced.points[5] = -2;
  forced.points[3] = -2;
  final forcedSeqs = forced.legalSequencesFor(Checker.white, [5, 2]);
  check(forcedSeqs.isNotEmpty && forcedSeqs.every((s) => s.length == 1),
      'Blocked alternatives collapse the turn to the one playable die');

  // --- Scoring, no doubling cube ------------------------------------
  final gammon = Board.empty();
  gammon.whiteOff = 15;
  gammon.points[10] = -3; // Black bore off none, none in White home/bar
  gammon.points[20] = -12;
  check(gammon.gamePoints(Checker.white) == 2, 'Gammon scores 2');
  final backgammon = Board.empty();
  backgammon.whiteOff = 15;
  backgammon.blackBar = 1;
  backgammon.points[20] = -14;
  check(backgammon.gamePoints(Checker.white) == 3, 'Backgammon scores 3');
  final single = Board.empty();
  single.whiteOff = 15;
  single.blackOff = 4;
  single.points[20] = -11;
  check(single.gamePoints(Checker.white) == 1, 'Single game scores 1');

  // --- Dice: factor reporting and fallbacks --------------------------
  final both = DiceRoller(
    gpsProvider: () => const GpsFix(39.7392, -104.9903),
    secureRandom: Random(42),
  );
  final rBoth = both.rollPair();
  check(rBoth.seedSource.contains('clock-time') && rBoth.seedSource.contains('GPS'),
      'Time + GPS are both used when available (${rBoth.seedSource})');
  check(rBoth.die1 >= 1 && rBoth.die1 <= 6 && rBoth.die2 >= 1 && rBoth.die2 <= 6,
      'Dice faces are 1-6');

  final timeOnly = DiceRoller(gpsProvider: () => null, secureRandom: Random(7));
  final rTime = timeOnly.rollPair();
  check(rTime.seedSource.contains('clock-time') && !rTime.seedSource.contains('GPS'),
      'Time-only fallback works (${rTime.seedSource})');

  final neither = DiceRoller(
    clock: () => throw StateError('no clock'),
    gpsProvider: () => null,
    secureRandom: Random(9),
  );
  final rNeither = neither.rollPair();
  check(rNeither.seedSource.contains('fallback'),
      'Neither factor -> fallback method (${rNeither.seedSource})');

  // Determinism under a test seed, and reasonable spread.
  final t1 = DiceRoller(testSeed: 1234);
  final t2 = DiceRoller(testSeed: 1234);
  var same = true;
  final faces = <int, int>{};
  for (var i = 0; i < 600; i++) {
    final a = t1.rollPair();
    final b = t2.rollPair();
    if (a.die1 != b.die1 || a.die2 != b.die2) same = false;
    faces[a.die1] = (faces[a.die1] ?? 0) + 1;
    faces[a.die2] = (faces[a.die2] ?? 0) + 1;
  }
  check(same, 'Test-seeded rolls are repeatable');
  check(faces.length == 6 && faces.values.every((n) => n > 140 && n < 260),
      'Dice spread is roughly even over 1200 rolls: $faces');

  // --- Computer opponent ---------------------------------------------
  final ai = ComputerPlayer();
  final aiMoves = ai.choose(Board.initial(), Checker.black, [6, 1]);
  check(aiMoves.isNotEmpty, 'Computer finds a move for an opening 6-1');

  // Difficulty levels: every level returns a genuinely legal play.
  final legalKeys = start
      .legalSequencesFor(Checker.black, [3, 1])
      .map((s) => s.map((m) => '${m.from}>${m.to}').join(','))
      .toSet();
  String keyOf(List<Move> seq) =>
      seq.map((m) => '${m.from}>${m.to}').join(',');
  final easy =
      ComputerPlayer(difficulty: Difficulty.easy, random: Random(7));
  check(legalKeys.contains(keyOf(easy.choose(start, Checker.black, [3, 1]))),
      'Easy plays a legal move (random choice)');
  final medium = ComputerPlayer(difficulty: Difficulty.medium);
  check(legalKeys.contains(keyOf(medium.choose(start, Checker.black, [3, 1]))),
      'Medium plays a legal move');
  final hard = ComputerPlayer(difficulty: Difficulty.hard);
  check(legalKeys.contains(keyOf(hard.choose(start, Checker.black, [3, 1]))),
      'Hard plays a legal move (with lookahead)');
  check(
      Difficulty.tryParse('hard') == Difficulty.hard &&
          Difficulty.tryParse(' Easy ') == Difficulty.easy &&
          Difficulty.tryParse('grandmaster') == null,
      'Difficulty names parse, unknown names rejected');
  // A hit on offer: Medium and Hard should both take it. Black has
  // one checker on point 8, a white blot sits on point 10, and
  // Black rolls 2-3 (points hold signed counts: negative = Black).
  // The hit lands outside Black's home board, so White — who must
  // re-enter there from the bar — cannot return-hit at once. (A hit
  // landing loose inside the home board is a genuinely closer call,
  // and Hard is allowed to decline it.)
  final hitBoard = Board.empty();
  hitBoard.points[8] = -1;
  hitBoard.points[10] = 1;
  bool hitsBlot(ComputerPlayer p) {
    final seq = p.choose(hitBoard, Checker.black, [2, 3]);
    var b = hitBoard;
    for (final mv in seq) {
      b = b.after(mv, Checker.black);
    }
    return b.barFor(Checker.white) == 1;
  }

  check(hitsBlot(medium), 'Medium takes a hit when one is offered');
  check(hitsBlot(hard), 'Hard takes a hit when one is offered');

  // --- Step-by-step turn builder (drag-and-drop engine) --------------
  final tb = TurnBuilder(Board.initial(), Checker.white, [3, 1]);
  check(tb.totalMoves == 2 && !tb.isComplete && tb.hasMove,
      'Turn builder: opening 3-1 is a 2-move turn');
  check(tb.movableSources.isNotEmpty && tb.possibleMoves.isNotEmpty,
      'Turn builder: offers legal first moves');
  final snapshot = tb.board;
  check(!tb.playFromTo(0, 5), 'Turn builder: an illegal move is rejected');
  check(identical(tb.board, snapshot) && tb.played.isEmpty,
      'Turn builder: a rejected move changes nothing');
  // Play a full legal sequence one move at a time.
  var guard = 0;
  while (!tb.isComplete && guard++ < 8) {
    final m = tb.possibleMoves.first;
    if (!tb.play(m)) break;
  }
  check(tb.isComplete && tb.played.length == 2,
      'Turn builder: step-by-step play completes the turn');
  check(tb.board.totalFor(Checker.white) == 15,
      'Turn builder: no checkers lost along the way');
  check(tb.undo() && !tb.isComplete && tb.played.length == 1,
      'Turn builder: undo takes back one move');
  final tbPass = TurnBuilder(Board.initial(), Checker.white, [3, 1]);
  check(tbPass.undo() == false, 'Turn builder: undo with no moves is a no-op');
  // A fully blocked position: White has a checker on the bar and
  // every entry point is held by 2+ Black checkers.
  final blocked = Board.empty();
  blocked.whiteBar = 1;
  for (var i = 18; i < 24; i++) {
    blocked.points[i] = -2;
  }
  final tbBlocked = TurnBuilder(blocked, Checker.white, [3, 4]);
  check(tbBlocked.isComplete && tbBlocked.totalMoves == 0,
      'Turn builder: a blocked turn is complete with no moves');

  // --- Match bookkeeping ----------------------------------------------
  final m = Match(targetPoints: 5);
  m.recordGame(Checker.white, Checker.white, 2);
  m.recordGame(Checker.black, Checker.white, 1);
  m.recordGame(Checker.white, Checker.white, 3);
  check(m.gamesPlayed == 3 && m.humanScore == 5 && m.isOver && m.humanWonMatch,
      'Match to 5 ends at 5 with correct bookkeeping');

  // --- Version ---------------------------------------------------------
  check(AppVersion.version == '1.2.3' && AppVersion.build == 6,
      'Version is ${AppVersion.display}');

  if (_failures > 0) {
    stderr.writeln('$_failures check(s) failed');
    exit(1);
  }
  stdout.writeln('All engine checks passed.');
}
