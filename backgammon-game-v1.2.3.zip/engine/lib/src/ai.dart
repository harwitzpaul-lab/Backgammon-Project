import 'dart:math';

import 'board.dart';

/// How strong the device opponent plays.
///
/// * [easy] — picks a legal play at random. Always rules-correct,
///   but with no plan: a relaxed game, good for learning.
/// * [medium] — the original heuristic player: one move ahead,
///   judging each finished position with [ComputerPlayer.evaluate].
/// * [hard] — the heuristic player plus lookahead: every candidate
///   play is also scored by what the opponent can do back, averaged
///   over all 21 possible reply rolls. It avoids leaving shots and
///   sets up hits a turn earlier than Medium.
enum Difficulty {
  easy,
  medium,
  hard;

  String get label => switch (this) {
        Difficulty.easy => 'Easy',
        Difficulty.medium => 'Medium',
        Difficulty.hard => 'Hard',
      };

  /// Parse a command-line / settings value; null when unrecognised.
  static Difficulty? tryParse(String text) {
    for (final d in Difficulty.values) {
      if (d.name == text.trim().toLowerCase()) return d;
    }
    return null;
  }
}

/// The device opponent. Deliberately a clear, explainable heuristic
/// player rather than a neural-net engine: it races when ahead, hits
/// when it can, makes points, keeps its own blots safer, and bears
/// off eagerly. The evaluation weights live in one place so Paul can
/// tune them.
class ComputerPlayer {
  final Difficulty difficulty;
  final Random _random;

  /// Above this many candidate plays, [Difficulty.hard] falls back
  /// to the Medium ranking (doubles can offer hundreds of plays;
  /// lookahead over all of them is not worth the wait).
  static const int hardLookaheadCap = 60;

  ComputerPlayer({this.difficulty = Difficulty.medium, Random? random})
      : _random = random ?? Random();

  /// Pick a legal sequence for [c] on board [b] with [dice],
  /// according to [difficulty]. Returns an empty list when no move
  /// is legal (a lost turn).
  List<Move> choose(Board b, Checker c, List<int> dice) {
    final options = b.legalSequencesFor(c, dice);
    if (options.isEmpty) return const [];
    return switch (difficulty) {
      Difficulty.easy => options[_random.nextInt(options.length)],
      Difficulty.medium => _bestBy(b, c, options, (after) => evaluate(after, c)),
      Difficulty.hard => options.length > hardLookaheadCap
          ? _bestBy(b, c, options, (after) => evaluate(after, c))
          : _bestBy(b, c, options, (after) => _lookaheadScore(after, c)),
    };
  }

  List<Move> _bestBy(Board b, Checker c, List<List<Move>> options,
      double Function(Board after) score) {
    List<Move> best = const [];
    var bestScore = double.negativeInfinity;
    for (final seq in options) {
      final s = score(_apply(b, c, seq));
      if (s > bestScore) {
        bestScore = s;
        best = seq;
      }
    }
    return best;
  }

  Board _apply(Board b, Checker c, List<Move> seq) {
    var after = b;
    for (final m in seq) {
      after = after.after(m, c);
    }
    return after;
  }

  /// Hard mode: the value of the position [after] my move, assuming
  /// the opponent then makes their best reply. Averaged over the 21
  /// distinct reply rolls (doubles count once in 36, other rolls
  /// twice). Winning immediately is worth a large bonus.
  double _lookaheadScore(Board after, Checker c) {
    if (after.isGameOver) return 10000 + evaluate(after, c);
    final opp = c.opponent;
    var total = 0.0;
    for (var d1 = 1; d1 <= 6; d1++) {
      for (var d2 = d1; d2 <= 6; d2++) {
        final weight = d1 == d2 ? 1 : 2;
        final replies = after.legalSequencesFor(opp, [d1, d2]);
        var replyBest = double.negativeInfinity;
        var replyBoard = after;
        for (final seq in replies) {
          final end = _apply(after, opp, seq);
          final s = evaluate(end, opp);
          if (s > replyBest) {
            replyBest = s;
            replyBoard = end;
          }
        }
        // Even an empty reply list leaves the board as it stands.
        total += weight * evaluate(replyBoard, c);
      }
    }
    return total / 36.0;
  }

  /// Static evaluation of a board from [c]'s point of view.
  /// Higher is better for [c].
  double evaluate(Board b, Checker c) {
    final opp = c.opponent;
    var score = 0.0;

    // Race: fewer pips remaining is better.
    score += (b.pipCount(opp) - b.pipCount(c)) * 1.0;

    // Borne-off checkers are permanent progress.
    score += (b.offFor(c) - b.offFor(opp)) * 18.0;

    // Checkers on the bar must waste a turn re-entering.
    score += (b.barFor(opp) - b.barFor(c)) * 22.0;

    for (var i = 0; i < 24; i++) {
      final mine = b.countFor(c, i);
      final theirs = b.countFor(opp, i);
      if (mine >= 2) {
        // Made points: worth more in my home board, and in the
        // opponent's home board (an anchor/prime there is valuable).
        score += 4;
        if (_inHome(i, c) || _inHome(i, opp)) score += 3;
      } else if (mine == 1) {
        // A blot: a small penalty, worse in my own home board.
        score -= _inHome(i, c) ? 5 : 3;
      }
      if (theirs >= 2) {
        score -= 4;
        if (_inHome(i, opp) || _inHome(i, c)) score -= 3;
      } else if (theirs == 1) {
        score += 2; // an opponent blot is a target
      }
    }
    return score;
  }

  bool _inHome(int idx, Checker c) =>
      c == Checker.white ? idx <= 5 : idx >= 18;
}
