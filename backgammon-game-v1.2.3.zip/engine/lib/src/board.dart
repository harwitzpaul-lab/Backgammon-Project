/// Core backgammon board, traditional rules, no doubling cube.
///
/// Board layout (internal indexes 0-23):
///   * White's home board is indexes 0-5, White's 1-point is index 0.
///   * White moves toward lower indexes and bears off past index 0.
///   * Black's home board is indexes 18-23, Black moves toward higher
///     indexes and bears off past index 23.
///   * Points hold signed counts: positive = White checkers,
///     negative = Black checkers.
/// Starting position (per player): 2 on the 24-point, 5 on the
/// 13-point, 3 on the 8-point, 5 on the 6-point.
enum Checker {
  white,
  black;

  Checker get opponent => this == Checker.white ? Checker.black : Checker.white;

  /// +1 for White, -1 for Black — matches the signed point counts.
  int get sign => this == Checker.white ? 1 : -1;

  String get label => this == Checker.white ? 'White' : 'Black';
}

const int barFrom = -1; // a move that starts on the bar
const int offTo = -2; // a move that bears a checker off

class Move {
  final int from; // barFrom, or a point index 0-23
  final int to; // offTo, or a point index 0-23
  final int die;
  final bool hits; // lands on an opponent blot, sending it to the bar

  const Move(this.from, this.to, this.die, {this.hits = false});

  /// Traditional notation from the moving player's point of view:
  /// points are numbered 1-24 from that player's own 1-point.
  String describe(Checker player) {
    String name(int idx, bool isFrom) {
      if (isFrom && idx == barFrom) return 'bar';
      if (!isFrom && idx == offTo) return 'off';
      return player == Checker.white ? '${idx + 1}' : '${24 - idx}';
    }

    return '${name(from, true)}/${name(to, false)}${hits ? '*' : ''}';
  }

  @override
  String toString() => 'Move($from->$to, die $die${hits ? ', hit' : ''})';
}

class Board {
  final List<int> points;
  int whiteBar;
  int blackBar;
  int whiteOff;
  int blackOff;

  Board(this.points,
      {this.whiteBar = 0,
      this.blackBar = 0,
      this.whiteOff = 0,
      this.blackOff = 0});

  factory Board.empty() => Board(List.filled(24, 0));

  factory Board.initial() {
    final b = Board.empty();
    void place(Checker c, int traditionalPoint, int count) {
      final idx =
          c == Checker.white ? traditionalPoint - 1 : 24 - traditionalPoint;
      b.points[idx] = count * c.sign;
    }

    for (final c in Checker.values) {
      place(c, 24, 2);
      place(c, 13, 5);
      place(c, 8, 3);
      place(c, 6, 5);
    }
    return b;
  }

  Board clone() => Board(List.of(points),
      whiteBar: whiteBar,
      blackBar: blackBar,
      whiteOff: whiteOff,
      blackOff: blackOff);

  int countFor(Checker c, int idx) {
    final v = points[idx];
    return c == Checker.white ? (v > 0 ? v : 0) : (v < 0 ? -v : 0);
  }

  int barFor(Checker c) => c == Checker.white ? whiteBar : blackBar;
  int offFor(Checker c) => c == Checker.white ? whiteOff : blackOff;

  int totalFor(Checker c) {
    var t = barFor(c) + offFor(c);
    for (var i = 0; i < 24; i++) {
      t += countFor(c, i);
    }
    return t;
  }

  /// Pips still needed to bear off every checker (bar counts 25).
  int pipCount(Checker c) {
    var pips = barFor(c) * 25;
    for (var i = 0; i < 24; i++) {
      final n = countFor(c, i);
      if (n == 0) continue;
      pips += n * (c == Checker.white ? i + 1 : 24 - i);
    }
    return pips;
  }

  bool isBlockedFor(Checker c, int idx) => countFor(c.opponent, idx) >= 2;

  bool allInHome(Checker c) {
    if (barFor(c) > 0) return false;
    if (c == Checker.white) {
      for (var i = 6; i < 24; i++) {
        if (countFor(c, i) > 0) return false;
      }
    } else {
      for (var i = 0; i < 18; i++) {
        if (countFor(c, i) > 0) return false;
      }
    }
    return true;
  }

  bool get isGameOver => whiteOff == 15 || blackOff == 15;

  Checker? get winner =>
      whiteOff == 15 ? Checker.white : (blackOff == 15 ? Checker.black : null);

  /// Apply a move, returning a new board (this board is unchanged).
  Board after(Move m, Checker c) {
    final b = clone();
    // Remove the moving checker from its source.
    if (m.from == barFrom) {
      if (c == Checker.white) {
        b.whiteBar--;
      } else {
        b.blackBar--;
      }
    } else {
      b.points[m.from] -= c.sign;
    }
    // Place it at its destination.
    if (m.to == offTo) {
      if (c == Checker.white) {
        b.whiteOff++;
      } else {
        b.blackOff++;
      }
    } else {
      if (m.hits) {
        b.points[m.to] = 0;
        if (c.opponent == Checker.white) {
          b.whiteBar++;
        } else {
          b.blackBar++;
        }
      }
      b.points[m.to] += c.sign;
    }
    return b;
  }

  /// Every single-checker move available for one die value.
  List<Move> singleMoves(Checker c, int die) {
    final moves = <Move>[];
    void tryLand(int from, int to) {
      if (isBlockedFor(c, to)) return;
      moves.add(Move(from, to, die, hits: countFor(c.opponent, to) == 1));
    }

    // A checker on the bar must re-enter before anything else moves.
    if (barFor(c) > 0) {
      final entry = c == Checker.white ? 24 - die : die - 1;
      tryLand(barFrom, entry);
      return moves;
    }

    final canBearOff = allInHome(c);
    for (var i = 0; i < 24; i++) {
      if (countFor(c, i) == 0) continue;
      if (c == Checker.white) {
        final dest = i - die;
        if (dest >= 0) {
          tryLand(i, dest);
        } else if (canBearOff) {
          final exact = dest == -1;
          final higherWithNoneBeyond =
              dest < -1 && !_anyOn(c, i + 1, 5); // no checker on a higher point
          if (exact || higherWithNoneBeyond) {
            moves.add(Move(i, offTo, die));
          }
        }
      } else {
        final dest = i + die;
        if (dest <= 23) {
          tryLand(i, dest);
        } else if (canBearOff) {
          final exact = dest == 24;
          final higherWithNoneBeyond =
              dest > 24 && !_anyOn(c, 18, i - 1);
          if (exact || higherWithNoneBeyond) {
            moves.add(Move(i, offTo, die));
          }
        }
      }
    }
    return moves;
  }

  bool _anyOn(Checker c, int fromIdx, int toIdx) {
    if (fromIdx > toIdx) return false;
    for (var i = fromIdx; i <= toIdx; i++) {
      if (countFor(c, i) > 0) return true;
    }
    return false;
  }

  /// All complete, rule-legal ways to play a roll for player [c].
  ///
  /// Enforces the traditional turn rules:
  ///   * doubles are played four times;
  ///   * a player must use as many of the rolled numbers as possible;
  ///   * if only one of two different numbers can be played, the
  ///     higher number must be played.
  List<List<Move>> legalSequencesFor(Checker c, List<int> dice) {
    final rolls = dice[0] == dice[1]
        ? [dice[0], dice[0], dice[0], dice[0]]
        : dice;
    final results = <List<Move>>[];

    void dfs(Board b, List<int> remaining, List<Move> soFar) {
      if (remaining.isEmpty) {
        results.add(List.of(soFar));
        return;
      }
      var moved = false;
      final triedDice = <int>{};
      for (final die in remaining) {
        if (!triedDice.add(die)) continue;
        for (final m in b.singleMoves(c, die)) {
          moved = true;
          final next = List<int>.of(remaining)..remove(die);
          dfs(b.after(m, c), next, [...soFar, m]);
        }
      }
      if (!moved) results.add(List.of(soFar));
    }

    dfs(this, List.of(rolls), const []);

    if (results.isEmpty) return const [];
    var maxLen = 0;
    for (final s in results) {
      if (s.length > maxLen) maxLen = s.length;
    }
    var best = results.where((s) => s.length == maxLen).toList();

    // Higher-die rule: only one number playable, and both numbers
    // could have been played on their own -> the higher one is forced.
    if (dice[0] != dice[1] && maxLen == 1 && best.isNotEmpty) {
      final diceUsed = best.map((s) => s.single.die).toSet();
      if (diceUsed.length > 1) {
        final high = dice.reduce((a, b) => a > b ? a : b);
        best = best.where((s) => s.single.die == high).toList();
      }
    }

    // Deduplicate identical move lists.
    final seen = <String>{};
    best.retainWhere((s) => seen.add(s.map((m) => m.toString()).join(';')));
    return best;
  }

  /// Points scored by [winner] in a finished game, with no doubling
  /// cube (Paul's specification): single game 1, gammon 2,
  /// backgammon 3.
  int gamePoints(Checker winner) {
    final loser = winner.opponent;
    if (offFor(loser) > 0) return 1;
    final loserOnBar = barFor(loser) > 0;
    var loserInWinnerHome = false;
    if (winner == Checker.white) {
      for (var i = 0; i <= 5; i++) {
        if (countFor(loser, i) > 0) loserInWinnerHome = true;
      }
    } else {
      for (var i = 18; i <= 23; i++) {
        if (countFor(loser, i) > 0) loserInWinnerHome = true;
      }
    }
    return (loserOnBar || loserInWinnerHome) ? 3 : 2;
  }

  /// Compact text rendering, White's 13-24 points on top, 12-1 below.
  String render() {
    String cell(int idx) {
      final v = points[idx];
      if (v == 0) return '  . ';
      final ch = v > 0 ? 'W' : 'B';
      return ' $ch${v.abs()} '.padRight(4).substring(0, 4);
    }

    final top = StringBuffer();
    for (var i = 12; i < 24; i++) {
      top.write(cell(i));
    }
    final bottom = StringBuffer();
    for (var i = 11; i >= 0; i--) {
      bottom.write(cell(i));
    }
    return ' 13-24: $top\n'
        '  12-1: $bottom\n'
        ' Bar: W$whiteBar B$blackBar   Off: W$whiteOff B$blackOff   '
        'Pips: W${pipCount(Checker.white)} B${pipCount(Checker.black)}';
  }
}
