/// The program's current version.
///
/// Paul can raise it with:
///
///   dart run tool/bump_version.dart patch   (1.0.0 -> 1.0.1)
///   dart run tool/bump_version.dart minor   (1.0.0 -> 1.1.0)
///   dart run tool/bump_version.dart major   (1.0.0 -> 2.0.0)
///   dart run tool/bump_version.dart build   (build number +1 only)
///
/// The same version is mirrored in `pubspec.yaml` (and in the Flutter
/// app's `pubspec.yaml`) as `version: 1.0.0+1` — semantic version, then
/// `+`, then the build number. The bump tool keeps all of them in sync.
class AppVersion {
  static const String version = '1.2.3';
  static const int build = 6;

  static String get display => '$version+$build';
}
