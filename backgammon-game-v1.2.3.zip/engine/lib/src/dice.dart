import 'dart:math';

/// Dice rolling for the backgammon game, built to Paul's specification:
///
/// * The device clock-time and the device's GPS coordinates are used as
///   factors in seeding the random generation of each pair of dice,
///   whenever they are available.
/// * If only one of them can be obtained, that one is used.
/// * If neither can be obtained, a different random method is used.
///
/// One deliberate safety refinement, required by Paul's own
/// anti-tampering requirement: clock-time and GPS are never the *only*
/// seed. Both are predictable — an opponent who knows roughly when and
/// where a roll happened could reproduce a time+GPS-only sequence and
/// predict future dice. So the time and GPS values are mixed with
/// entropy from the operating system's secure random source
/// (`Random.secure()`). Time and GPS are therefore genuine seed
/// factors in every roll where they exist, exactly as specified, but
/// on their own they cannot be used to forecast the dice.
///
/// Fallback chain, per roll:
///   time + GPS available  -> time + GPS + OS secure entropy
///   only time available   -> time + OS secure entropy
///   only GPS available    -> GPS + OS secure entropy
///   neither available     -> OS secure entropy alone
///   (and if the OS offers no secure source at all, a last-resort
///    clock-seeded Random, which the `seedSource` text honestly
///    reports as 'last-resort fallback')
class DiceRoll {
  final int die1;
  final int die2;

  /// Human-readable account of which seed factors this roll used.
  final String seedSource;

  const DiceRoll(this.die1, this.die2, this.seedSource);

  bool get isDouble => die1 == die2;
  List<int> get values => [die1, die2];

  @override
  String toString() => '$die1-$die2 (seed: $seedSource)';
}

/// Supplies GPS coordinates, when the device and the user's permission
/// allow it. On the phone/desktop builds this is backed by the
/// platform location service; it returns null when location is off,
/// permission is denied, or the device has no GPS — all normal cases,
/// especially on Windows and Mac machines.
class GpsFix {
  final double latitude;
  final double longitude;
  const GpsFix(this.latitude, this.longitude);
}

class DiceRoller {
  final DateTime Function() _clock;
  final GpsFix? Function()? _gpsProvider;
  final Random? _secureOverride;
  final int? _testSeed;
  int _counter = 0;
  int _state = 0;

  /// [clock] defaults to the device clock. [gpsProvider] is called
  /// before each roll and may return null (no fix available).
  /// [testSeed] is for automated tests only: it makes rolls repeatable.
  DiceRoller({
    DateTime Function()? clock,
    GpsFix? Function()? gpsProvider,
    Random? secureRandom,
    int? testSeed,
  })  : _clock = clock ?? DateTime.now,
        _gpsProvider = gpsProvider,
        _secureOverride = secureRandom,
        _testSeed = testSeed;

  /// Roll the pair of dice used for one turn.
  DiceRoll rollPair() {
    final buffer = StringBuffer();
    final d1 = _nextDie(buffer);
    final source = buffer.toString();
    final d2 = _nextDie(StringBuffer());
    return DiceRoll(d1, d2, source);
  }

  /// Roll a single die (used for the opening roll-off).
  int rollSingle() => _nextDie(StringBuffer());

  int _nextDie(StringBuffer sourceOut) {
    _counter++;
    final testSeed = _testSeed;
    if (testSeed != null) {
      _state = _splitMix(testSeed + _counter * 0x9E3779B97F4A7C15);
      sourceOut.write('test seed');
      return _dieFrom(_state);
    }

    final factors = <String>[];

    // Factor 1: device clock-time, to the microsecond, at this roll.
    int? micros;
    try {
      micros = _clock().microsecondsSinceEpoch;
      factors.add('clock-time');
    } catch (_) {
      micros = null;
    }

    // Factor 2: GPS coordinates, when a fix is available.
    GpsFix? fix;
    try {
      fix = _gpsProvider?.call();
    } catch (_) {
      fix = null;
    }
    if (fix != null) factors.add('GPS');

    // Anti-prediction entropy from the OS, mixed in whenever offered.
    int? secureBits;
    var secureFailed = false;
    try {
      final r = _secureOverride ?? Random.secure();
      secureBits = (r.nextInt(1 << 32) << 32) | r.nextInt(1 << 32);
      factors.add('OS secure random');
    } catch (_) {
      secureFailed = true;
    }

    final entropy = StringBuffer()
      ..write(micros ?? 'notime')
      ..write('|')
      ..write(fix == null
          ? 'nogps'
          : '${fix.latitude.toStringAsFixed(6)},'
              '${fix.longitude.toStringAsFixed(6)}')
      ..write('|')
      ..write(secureBits ?? 'nosecure')
      ..write('|')
      ..write(_counter);
    _state = _fnv1a64(entropy.toString()) ^ _splitMix(_counter * 7919 + 13);
    _state = _splitMix(_state);

    if (secureFailed && factors.isEmpty) {
      sourceOut.write('last-resort fallback random');
    } else if (factors.length == 1 && factors.single == 'OS secure random') {
      sourceOut.write('OS secure random (fallback: no clock-time, no GPS)');
    } else {
      sourceOut.write(factors.join(' + '));
    }
    return _dieFrom(_state);
  }

  /// Turn a 64-bit value into an unbiased die face (rejection of the
  /// modulo-bias range, rather than a bare `% 6` on the raw stream).
  int _dieFrom(int value) {
    var v = value & 0x7FFFFFFFFFFFFFFF;
    // Largest multiple of 6 that fits in 63 bits; re-draw (advance the
    // state) in the vanishingly rare case we land above it.
    const limit = 9223372036854775806; // 2^63 - 2, divisible by 6
    while (v >= limit) {
      _state = _splitMix(_state + 1);
      v = _state & 0x7FFFFFFFFFFFFFFF;
    }
    return v % 6 + 1;
  }

  static int _fnv1a64(String s) {
    var hash = 0xcbf29ce484222325;
    for (final unit in s.codeUnits) {
      hash ^= unit;
      hash = (hash * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF;
    }
    return hash;
  }

  static int _splitMix(int x) {
    var z = (x + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF;
    z = ((z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF;
    z = ((z ^ (z >>> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF;
    return (z ^ (z >>> 31)) & 0xFFFFFFFFFFFFFFFF;
  }
}
