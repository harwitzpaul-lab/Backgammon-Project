import 'board.dart';

/// Builds one turn move-by-move — the engine behind drag-and-drop
/// (and tap-to-move) play in the app.
///
/// Full legal plays come from [Board.legalSequencesFor], which
/// already enforces "use as many dice as possible" and the
/// higher-die rule, and every returned sequence has the same
/// length. A [TurnBuilder] lets the player commit those moves one
/// at a time: at each step, [possibleMoves] lists the distinct
/// next moves that keep at least one full legal play alive, and
/// [play] commits one. Because every choice is filtered against
/// the surviving sequences, a player can never paint themselves
/// into an illegal corner — any move the builder accepts can
/// always be completed into a fully legal turn.
class TurnBuilder {
  final Checker player;

  Board _board;
  List<List<Move>> _remaining;
  final List<Move> _played = [];
  final List<Board> _boardHistory = [];
  final List<List<List<Move>>> _remainingHistory = [];

  TurnBuilder(Board start, this.player, List<int> dice)
      : _board = start,
        _remaining = start.legalSequencesFor(player, dice);

  /// The board as it stands, with the moves played so far applied.
  Board get board => _board;

  /// Moves committed so far this turn, in order.
  List<Move> get played => List.unmodifiable(_played);

  /// How many moves the full turn consists of. When the dice allow
  /// no move at all this is 0 and the turn is complete immediately.
  int get totalMoves =>
      _remaining.isEmpty ? _played.length : _played.length + _remaining.first.length;

  /// True when every move of the turn has been committed (or none
  /// was possible in the first place).
  bool get isComplete => _remaining.isNotEmpty && _remaining.first.isEmpty;

  /// True when at least one move can still be played.
  bool get hasMove => !isComplete && _remaining.isNotEmpty;

  /// The distinct legal next moves, one per (from, to) pair.
  List<Move> get possibleMoves {
    final seen = <String>{};
    final out = <Move>[];
    for (final seq in _remaining) {
      if (seq.isEmpty) continue;
      final m = seq.first;
      if (seen.add('${m.from}>${m.to}')) out.add(m);
    }
    return out;
  }

  /// The distinct point indexes (or [barFrom]) a checker can
  /// legally move FROM right now — used to light up draggable
  /// checkers.
  Set<int> get movableSources => possibleMoves.map((m) => m.from).toSet();

  /// The distinct destinations reachable from [from] right now
  /// (point indexes, or [offTo] for bearing off).
  Set<int> targetsFrom(int from) =>
      possibleMoves.where((m) => m.from == from).map((m) => m.to).toSet();

  /// Commit the move identified by its endpoints. Returns false —
  /// and changes nothing — when that move is not currently legal.
  bool playFromTo(int from, int to) {
    for (final m in possibleMoves) {
      if (m.from == from && m.to == to) return play(m);
    }
    return false;
  }

  /// Commit a specific [Move] from [possibleMoves].
  bool play(Move move) {
    final next = <List<Move>>[];
    for (final seq in _remaining) {
      if (seq.isNotEmpty &&
          seq.first.from == move.from &&
          seq.first.to == move.to &&
          seq.first.die == move.die) {
        next.add(seq.sublist(1));
      }
    }
    if (next.isEmpty) return false;
    _boardHistory.add(_board);
    _remainingHistory.add(_remaining);
    _board = _board.after(move, player);
    _remaining = next;
    _played.add(move);
    return true;
  }

  /// Take back the last committed move. Returns false when there
  /// is nothing to take back.
  bool undo() {
    if (_played.isEmpty) return false;
    _played.removeLast();
    _board = _boardHistory.removeLast();
    _remaining = _remainingHistory.removeLast();
    return true;
  }
}
