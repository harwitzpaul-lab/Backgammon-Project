import 'board.dart';

/// Score-keeping for a match, following the convention used by
/// popular electronic backgammon games:
///
///   * A match is a series of games played to a target number of
///     points — commonly 3, 5 or 7 (5 is the default here); a single
///     untimed game is a match to 1.
///   * Each game scores 1 point for a normal win, 2 for a gammon
///     (loser bore off no checkers), 3 for a backgammon (loser bore
///     off none and still has a checker on the bar or in the
///     winner's home board).
///   * There is NO doubling cube (Paul's specification), so no
///     Crawford/Jacoby cube rules arise: those only govern cube use.
class Match {
  /// Points needed to win the match. Defaults to 5.
  final int targetPoints;

  int humanScore = 0;
  int deviceScore = 0;
  int gamesPlayed = 0;
  int humanGamesWon = 0;
  int deviceGamesWon = 0;

  Match({this.targetPoints = 5});

  bool get isOver => humanScore >= targetPoints || deviceScore >= targetPoints;
  bool get humanWonMatch => humanScore >= targetPoints;

  /// Record a finished game. [winner] is the winning colour;
  /// [humanColour] is the colour the human chose; [points] comes from
  /// Board.gamePoints.
  void recordGame(Checker winner, Checker humanColour, int points) {
    gamesPlayed++;
    if (winner == humanColour) {
      humanScore += points;
      humanGamesWon++;
    } else {
      deviceScore += points;
      deviceGamesWon++;
    }
  }

  String summary(Checker humanColour) =>
      'Games played: $gamesPlayed '
      '(you won $humanGamesWon, device won $deviceGamesWon) — '
      'match score: you $humanScore, device $deviceScore '
      '(first to $targetPoints)'
      '${isOver ? (humanWonMatch ? ' — you win the match!' : ' — the device wins the match.') : ''}';
}
