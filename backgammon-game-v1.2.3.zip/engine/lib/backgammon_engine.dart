/// Platform-independent backgammon engine: one codebase shared by the
/// Android, iOS, Windows and macOS builds of Paul's game.
library;

export 'src/ai.dart';
export 'src/board.dart';
export 'src/dice.dart';
export 'src/match.dart';
export 'src/turn.dart';
export 'src/version.dart';
