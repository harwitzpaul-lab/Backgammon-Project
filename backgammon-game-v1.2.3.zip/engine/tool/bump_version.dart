/// Increment the program's version, keeping every copy in sync:
///
///   dart run tool/bump_version.dart patch|minor|major|build
///
/// Updates:
///   * lib/src/version.dart          (AppVersion)
///   * this package's pubspec.yaml   (version: X.Y.Z+B)
///   * ../app/pubspec.yaml           (the Flutter app), when present
import 'dart:io';

void main(List<String> args) {
  final kind = args.isEmpty ? 'build' : args[0];
  final versionFile = File('lib/src/version.dart');
  final text = versionFile.readAsStringSync();
  final m = RegExp(r"version = '(\d+)\.(\d+)\.(\d+)'").firstMatch(text);
  final b = RegExp(r'build = (\d+)').firstMatch(text);
  if (m == null || b == null) {
    stderr.writeln('Could not read the current version from $versionFile');
    exit(1);
  }
  var major = int.parse(m.group(1)!);
  var minor = int.parse(m.group(2)!);
  var patch = int.parse(m.group(3)!);
  var build = int.parse(b.group(1)!);

  switch (kind) {
    case 'major':
      major++;
      minor = 0;
      patch = 0;
      build++;
    case 'minor':
      minor++;
      patch = 0;
      build++;
    case 'patch':
      patch++;
      build++;
    case 'build':
      build++;
    default:
      stderr.writeln('Usage: bump_version.dart patch|minor|major|build');
      exit(1);
  }

  final version = '$major.$minor.$patch';
  versionFile.writeAsStringSync(text
      .replaceFirst(
          RegExp(r"version = '\d+\.\d+\.\d+'"), "version = '$version'")
      .replaceFirst(RegExp(r'build = \d+'), 'build = $build'));

  for (final path in ['pubspec.yaml', '../app/pubspec.yaml']) {
    final f = File(path);
    if (!f.existsSync()) continue;
    f.writeAsStringSync(f.readAsStringSync().replaceFirst(
        RegExp(r'^version: .*', multiLine: true),
        'version: $version+$build'));
  }
  stdout.writeln('Version is now $version+$build');
}
