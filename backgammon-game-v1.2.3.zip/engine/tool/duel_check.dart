import 'dart:math';
import 'package:backgammon_engine/backgammon_engine.dart';

Checker playGame(ComputerPlayer white, ComputerPlayer black, DiceRoller roller) {
  var board = Board.initial();
  var w = roller.rollSingle();
  var b = roller.rollSingle();
  while (w == b) { w = roller.rollSingle(); b = roller.rollSingle(); }
  var turn = w > b ? Checker.white : Checker.black;
  var dice = [w, b];
  var guard = 0;
  while (!board.isGameOver && guard++ < 1000) {
    final ai = turn == Checker.white ? white : black;
    for (final m in ai.choose(board, turn, dice)) {
      board = board.after(m, turn);
    }
    if (board.isGameOver) break;
    turn = turn.opponent;
    dice = roller.rollPair().values;
  }
  return board.winner!;
}

void main() {
  final roller = DiceRoller(testSeed: 42);
  final hard = ComputerPlayer(difficulty: Difficulty.hard);
  final easy = ComputerPlayer(difficulty: Difficulty.easy, random: Random(9));
  var hardWins = 0, easyWins = 0;
  for (var g = 0; g < 12; g++) {
    // Alternate colours to cancel the first-move advantage.
    final winner = g.isEven
        ? playGame(hard, easy, roller)
        : playGame(easy, hard, roller);
    final hardWon = (g.isEven && winner == Checker.white) ||
        (g.isOdd && winner == Checker.black);
    if (hardWon) { hardWins++; } else { easyWins++; }
  }
  print('Hard $hardWins — Easy $easyWins (of 12 games)');
}
