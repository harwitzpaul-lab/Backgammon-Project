#!/usr/bin/env bash
# Backgammon — automatic Android installer build. Run anywhere with
# Flutter + the Android SDK (Linux, macOS or Windows/WSL):
#
#   bash installers/android/build_installer_android.sh
#
# Produces, in dist/ at the project root:
#   Backgammon-1.2.1.aab   — upload to Google Play (the store
#                            "installer": Play delivers it to devices)
#   Backgammon-1.2.1.apk   — install directly on a device
#                            (adb install, or open it on the phone)
#
# Signing: release builds are signed with the upload key when
# android/key.properties exists (see installers/README.md for how to
# create it). Without it, the build falls back to the debug key —
# installable for testing, NOT acceptable to Google Play.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/app"

VERSION="$(grep -E '^version:' pubspec.yaml | sed -E 's/version: *([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
echo "Building Backgammon $VERSION for Android..."

# The read-only BACKGAMMON-INFO.txt travels inside the .aab/.apk as
# a bundled app asset (declared in pubspec.yaml) — mobile installers
# cannot drop loose files onto a device, so the bundle is how the
# file is installed on Android (and iOS). Fail early if it is gone.
test -f assets/BACKGAMMON-INFO.txt || {
  echo "ERROR: app/assets/BACKGAMMON-INFO.txt is missing"; exit 1; }

if [ -f android/key.properties ]; then
  echo "Upload key found — release build will be properly signed."
else
  echo "NOTE: no android/key.properties — using the debug key."
  echo "      Fine for testing, not for Google Play. See installers/README.md."
fi

mkdir -p "$ROOT/dist"
flutter build appbundle --release --obfuscate --split-debug-info=build/symbols
cp build/app/outputs/bundle/release/app-release.aab "$ROOT/dist/Backgammon-$VERSION.aab"

flutter build apk --release --obfuscate --split-debug-info=build/symbols
cp build/app/outputs/flutter-apk/app-release.apk "$ROOT/dist/Backgammon-$VERSION.apk"

echo "Done: dist/Backgammon-$VERSION.aab and dist/Backgammon-$VERSION.apk"
