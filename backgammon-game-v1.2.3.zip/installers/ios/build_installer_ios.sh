#!/usr/bin/env bash
# Backgammon — automatic iOS installer (.ipa) build. Run on a Mac
# signed in to Xcode with Paul's Apple ID / developer team:
#
#   bash installers/ios/build_installer_ios.sh
#
# Produces: dist/Backgammon-1.2.1.ipa at the project root.
#
# How iOS "installers" work: there is no .exe/.pkg equivalent for
# iPhone/iPad — apps are delivered as an .ipa, installed by Xcode,
# Apple Configurator, TestFlight, or the App Store. The read-only
# BACKGAMMON-INFO.txt travels inside the .ipa as a bundled app
# asset (declared in app/pubspec.yaml). This script builds the
# .ipa using app/ios/ExportOptions.plist:
#   * method "debugging" (the default in that file) -> installable
#     on devices registered to Paul's team.
#   * switch the method to "app-store-connect" -> the same script
#     produces the build you upload to TestFlight / the App Store.
#
# Requirements: macOS + Xcode + Flutter. First run may ask you to
# sign in to Xcode (Settings > Accounts) and to trust the developer
# profile on the device (Settings > General > VPN & Device Mgmt).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/app"

VERSION="$(grep -E '^version:' pubspec.yaml | sed -E 's/version: *([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
echo "Building Backgammon $VERSION for iOS..."

mkdir -p "$ROOT/dist"
flutter build ipa --release --obfuscate --split-debug-info=build/symbols \
  --export-options-plist=ios/ExportOptions.plist

IPA="$(ls build/ios/ipa/*.ipa | head -1)"
cp "$IPA" "$ROOT/dist/Backgammon-$VERSION.ipa"
echo "Done: dist/Backgammon-$VERSION.ipa"
echo "Install it via Xcode (Window > Devices and Simulators),"
echo "Apple Configurator, or upload it to TestFlight/App Store Connect"
echo "if ExportOptions.plist is set to app-store-connect."
