#!/usr/bin/env bash
# Backgammon — automatic macOS installer build. Run on a Mac:
#
#   bash installers/macos/build_installer_macos.sh
#
# Does, in order:
#   1. Reads the version from app/pubspec.yaml
#   2. flutter build macos --release (with obfuscation)
#   3. Wraps the .app in an installer .pkg (productbuild)
#      AND a drag-to-install .dmg (hdiutil)
#   => dist/Backgammon-1.2.1.pkg  and  dist/Backgammon-1.2.1.dmg
#      at the project root. Both carry the read-only
#      BACKGAMMON-INFO.txt beside the app.
#
# Requirements: macOS with Xcode + Flutter SDK.
# Optional signing (needed for distribution outside your own Mac):
#   export BACKGAMMON_MAC_INSTALLER_ID="Developer ID Installer: Your Name (TEAMID)"
# With it unset, the .pkg is unsigned — fine for your own machines;
# Gatekeeper will ask the user to right-click > Open on first
# launch. Notarization (xcrun notarytool) is a separate step after
# signing; see installers/README.md.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/app"

VERSION="$(grep -E '^version:' pubspec.yaml | sed -E 's/version: *([0-9]+\.[0-9]+\.[0-9]+).*/\1/')"
echo "Building Backgammon $VERSION for macOS..."

flutter build macos --release --obfuscate --split-debug-info=build/symbols

APP="$(ls -d build/macos/Build/Products/Release/*.app | head -1)"
STAGE="$ROOT/staging"
mkdir -p "$ROOT/dist" "$STAGE"
rm -rf "$STAGE/payload" && mkdir -p "$STAGE/payload"
cp -R "$APP" "$STAGE/payload/"
# The read-only information file rides along in /Applications,
# with its read-only permissions preserved by the package.
cp "$ROOT/BACKGAMMON-INFO.txt" "$STAGE/payload/"
chmod 444 "$STAGE/payload/BACKGAMMON-INFO.txt"

# --- .pkg installer ------------------------------------------------
cat > "$STAGE/distribution.xml" <<XML
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
    <title>Backgammon $VERSION</title>
    <organization>com.example.backgammonGame</organization>
    <options customize="never" require-scripts="false" hostArchitectures="arm64,x86_64"/>
    <choices-outline>
        <line choice="default"/>
    </choices-outline>
    <choice id="default" visible="false">
        <pkg-ref id="backgammon.pkg"/>
    </choice>
    <pkg-ref id="backgammon.pkg" version="$VERSION">backgammon-component.pkg</pkg-ref>
</installer-gui-script>
XML

pkgbuild --root "$STAGE/payload" --identifier com.example.backgammonGame \
  --version "$VERSION" --install-location /Applications \
  "$STAGE/backgammon-component.pkg"
SIGN_ARGS=()
if [ -n "${BACKGAMMON_MAC_INSTALLER_ID:-}" ]; then
  SIGN_ARGS=(--sign "$BACKGAMMON_MAC_INSTALLER_ID")
fi
productbuild --distribution "$STAGE/distribution.xml" --package-path "$STAGE" \
  "${SIGN_ARGS[@]}" "$ROOT/dist/Backgammon-$VERSION.pkg"

# --- .dmg (drag to Applications) -----------------------------------
DMG_DIR="$(mktemp -d)"
cp -R "$APP" "$DMG_DIR/"
cp "$ROOT/BACKGAMMON-INFO.txt" "$DMG_DIR/"
chmod 444 "$DMG_DIR/BACKGAMMON-INFO.txt"
ln -s /Applications "$DMG_DIR/Applications"
hdiutil create -volname "Backgammon $VERSION" -srcfolder "$DMG_DIR" \
  -ov -format UDZO "$ROOT/dist/Backgammon-$VERSION.dmg"
rm -rf "$DMG_DIR" "$STAGE"

echo "Done: dist/Backgammon-$VERSION.pkg and dist/Backgammon-$VERSION.dmg"
