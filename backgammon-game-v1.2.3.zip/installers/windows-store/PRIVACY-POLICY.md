# Privacy Policy — Backgammon

**Effective date:** [date of first Store submission]
**App:** Backgammon, version 1.2.3 (Microsoft Store / MSIX 1.2.3.0)
**Developer:** Paul Harwitz — [contact email to be added]

## What this app does

Backgammon is a single-player board game. You play against the
device (the computer opponent). There are no accounts, no
in-app purchases, no advertising, no chat, and no user-generated
content. The game is played on your device.

## Location — the only permission the app uses

The app may ask for location permission. Location is used for
one purpose only: as a factor in seeding the dice rolls.

- The app requests a single, low-accuracy location fix when a
  game starts (and when a new game starts). It does not track
  your location continuously and does not record a location
  history.
- The coordinates are mixed on your device with the device
  clock-time and the operating system's secure random source to
  produce the dice seed. They are never the only seed factor,
  so a roll cannot be predicted from time or place alone.
- **Your location is never stored and never sent anywhere.**
  It is not transmitted to the developer, to Microsoft, or to
  any third party, and it is not used for advertising or
  analytics.
- If you deny location permission, or your device has no GPS,
  the game works exactly the same: the dice fall back to
  clock-time plus the operating system's secure random source.
  Nothing else changes.

## What we collect

Nothing. The app collects no personal information, no usage
data, and no diagnostics. It makes no network requests to the
developer and contains no analytics or advertising software.
No data leaves your device because of this app.

## Children's privacy

The game collects no information from anyone, including
children. There is nothing for a parent or guardian to request
be deleted, because nothing is stored.

## Changes to this policy

If the app ever changes how it handles data, this policy will
be updated before the changed version is submitted to the
Store, and the effective date above will change.

## Contact

Questions about this policy: [Paul's contact email to be added].
