# Microsoft Store submission — Partner Center checklist

Paul chose this route on 2026-11-15: distribute the Windows
version through the Microsoft Store as an MSIX package instead of
buying a code-signing certificate. The Store signs packages
itself, so Store installs never show the SmartScreen "unknown
publisher" prompt. The steps below that happen in Partner Center
can only be done by Paul (they need his Microsoft account and his
identity); everything on the project side is already prepared.

## Already done in the project

- `msix` package (v3.18) added as a dev dependency of the app.
- `msix_config` block in `app/pubspec.yaml` with `store: true`,
  the four-part Store version `1.2.3.0`, the `location` capability
  (the GPS dice-seed factor), and the Store logo
  (`app/assets/store_logo.png`).
- `build_msix.ps1` in this folder: builds the app and produces
  the unsigned Store package in `dist\` with one command.

## Paul's steps in Partner Center (one time)

1. **Developer account.** Sign in to Microsoft Partner Center
   (partner.microsoft.com) with your Microsoft account and open a
   **free individual developer account** — Microsoft now offers
   free registration for individual developers in most markets.
2. **Reserve the app name.** Apps and games → New product →
   "MSIX or PWA app" → enter **Backgammon** (or the name you
   prefer) → Check availability → Reserve product name. A
   reservation holds the name for 3 months, so do the first
   submission within that window.
3. **Copy the three identity values.** Open the app →
   Product identity, and send Muse these three values exactly
   as shown:
   - Package/Identity/Name
   - Package/Identity/Publisher (starts with `CN=`)
   - Package/Properties/PublisherDisplayName

   Muse will put them into `app/pubspec.yaml`, replacing the
   placeholders. The package will not be accepted by the Store
   until they match.
4. **Privacy policy URL.** The Store requires a public privacy
   policy page for an app that can access location. The game's
   policy is short and true: location is used only as a dice-seed
   factor, on-device, and is never stored or sent anywhere. The
   page needs a public web address; ask Muse to draft the text
   and suggest free hosting options.
5. **Screenshots.** At least one desktop screenshot of the game
   for the Store listing (taken from the running app on your
   Windows machine).

## Each release

1. On a Windows machine: `installers\windows-store\build_msix.ps1`
   (or the GitHub Actions pipeline, once a Windows Store job is
   added there).
2. Partner Center → the app → Start a submission → upload the
   package from `dist\`.
3. Fill in: pricing (Free), properties/category (Games →
   Board games), age ratings questionnaire (a board game with no
   chat, no purchases and no user content rates for everyone),
   and the Store listing text (Muse can draft it).
4. Submit for certification. Microsoft reviews the package
   (typically a few days) and then publishes it; the Store signs
   it with your publisher identity.

## Notes

- The direct-download console `.exe` (v1.2.1) is unaffected: it
  stays available as-is, still unsigned, with its one-time
  SmartScreen prompt. The Store route covers the graphical app.
- Version rule: every Store upload must have a higher four-part
  version than the last, and the last part (revision) must be 0 —
  the project's version-bump tool plus a matching `msix_version`
  edit handles this.
