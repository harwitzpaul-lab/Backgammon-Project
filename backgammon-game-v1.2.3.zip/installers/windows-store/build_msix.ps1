# Build the Microsoft Store package (.msix) for Backgammon.
#
# Run on a Windows machine with Flutter installed:
#   powershell -File installers\windows-store\build_msix.ps1
#
# What it does:
#   1. Builds the graphical Flutter Windows app in release mode.
#   2. Packages it as an UNSIGNED Store MSIX (store: true in
#      app/pubspec.yaml) into dist\. Microsoft re-signs Store
#      packages itself, so no code-signing certificate is needed —
#      that is exactly why Paul chose this route (2026-11-15).
#
# BEFORE the first run: replace the three identity placeholders in
# app/pubspec.yaml (publisher_display_name, identity_name,
# publisher) with the exact values from Partner Center > the app >
# Product identity, or the Store will reject the upload. See
# PARTNER-CENTER-CHECKLIST.md in this folder.
#
# Upload the resulting .msix (or the .msixupload the tool reports)
# in Partner Center under the app's submission > Packages.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)

Set-Location "$root\app"
flutter build windows --release
if ($LASTEXITCODE -ne 0) { throw 'flutter build windows failed' }

dart run msix:create --store
if ($LASTEXITCODE -ne 0) { throw 'msix:create failed' }

Write-Host ''
Write-Host 'Store package created in dist\ — upload it in Partner Center.'
