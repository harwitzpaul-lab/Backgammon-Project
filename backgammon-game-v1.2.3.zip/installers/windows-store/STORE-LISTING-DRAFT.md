# Microsoft Store listing — draft (2026-11-15, updated to v1.2.3 on 2026-11-16)

Prepared for Paul Harwitz, Backgammon v1.2.3 (MSIX 1.2.3.0).
Nothing here is submitted or published. Fill in the bracketed items
at submission time; the listing text itself needs no Partner Center
values, so it could be drafted now.

Source of every claim: `workspace/goals/backgammon-desktop-game/files/backgammon-project-spec.md`
(v1.2.1 spec, updated for v1.2.3) and
`workspace/backgammon-game/installers/windows-store/PARTNER-CENTER-CHECKLIST.md`.

## Submission facts (from the checklist)

- App name: **Backgammon** — [confirm once the name is reserved in Partner Center]
- Price: **Free**
- Category: **Games → Board games**
- Age rating: board game, no chat, no purchases, no user content — rates for everyone
  (complete the questionnaire at submission; this is the expected outcome, not a guarantee)
- Privacy policy URL: [pending — `docs/privacy-policy.html` is prepared for GitHub Pages; once the repo is published, enable Pages (Settings → Pages → Deploy from a branch → main → /docs) and the URL is `https://<username>.github.io/<repo>/privacy-policy.html`. Still needs Paul's contact email and the submission date filled in.]
- Support contact email: [pending — same email Paul gives for the privacy policy]
- Screenshot: [at least one desktop screenshot, taken from the game running on Paul's Windows machine]

## Short description (Store listing header)

Classic backgammon against the computer — free, with no ads and no
in-app purchases. Choose white or black, pick your difficulty, and
play traditional backgammon with no doubling cube.

## Full description (draft)

Backgammon is the classic board game, played against your device.
You choose white or black at the start, then play traditional
backgammon rules — hit blots, re-enter from the bar, bear off all
fifteen checkers to win. There is no doubling cube.

Three difficulty levels suit every player:

- **Easy** — a relaxed, rules-correct opponent, good for learning the game.
- **Medium** — a one-move-ahead opponent that races when ahead, hits
  blots, makes points and bears off eagerly.
- **Hard** — looks ahead at your best reply to every candidate play,
  averaged over all 21 possible reply rolls. In testing, Hard beat
  Easy 12–0 over 12 games.

Play on a drawn board with triangular points, round checkers, a centre
bar and borne-off trays. Drag a checker to a lit destination, or tap a
checker and then its destination — only legal moves are offered, and
you can undo a move within your turn. If a roll leaves you no legal
move, the game tells you so and waits for you to acknowledge it
before the computer takes its turn.

Matches are scored the traditional way — a single game is 1 point,
a gammon 2, a backgammon 3 — played to a target of 3, 5, 7 or 11
points (5 by default). Dice rolls are seeded on your device from the
clock and, when you allow it, your location; your location is never
stored or sent anywhere, and the game plays exactly the same if you
decline. There are no accounts, no ads, no in-app purchases, and the
game needs no internet connection.

© Paul Harwitz. Authorized for totally free distribution and use only.
All Rights Reserved. / Tous Droits Réservés. / Alle Rechte vorbehalten.

## Features (bullet list for the Store page)

- Single-player backgammon against the computer
- Play as white or black — your choice
- Traditional rules, no doubling cube
- Three difficulty levels: Easy, Medium, Hard
- Drawn board with drag-and-drop or tap-to-move, legal moves highlighted
- Undo within your turn; clear alert when no move is available
- Match scoring (single / gammon / backgammon) to 3, 5, 7 or 11 points
- Free — no ads, no in-app purchases, no accounts, no internet needed

## What's new in 1.2.3 (for the submission's release notes)

This will be the first Store submission, so the notes carry forward
the 1.2.2 graphical changes. (v1.2.3 itself changed only the
text/console edition — a how-to-play start screen, a cleared screen
each turn, and a two-column move list — so there is nothing new to
list for the graphical Store app in 1.2.3.)

- A "No further moves available" alert with an OK button: the
  computer's turn now starts only after you acknowledge it.
- Copyright and free-distribution notices added to the game and its
  information file: © Paul Harwitz, "Authorized for totally free
  distribution and use only.", "All Rights Reserved." /
  "Tous Droits Réservés." / "Alle Rechte vorbehalten."

## Still needed from Paul before submission (unchanged)

1. Reserve the app name in Partner Center and send Muse the three
   Product identity values (Identity/Name, Identity/Publisher,
   PublisherDisplayName).
2. Contact email for the privacy policy and this listing.
3. Host for the privacy policy (GitHub Pages is the natural free
   option — the project already has a GitHub Actions pipeline).
4. One desktop screenshot of the game running on his Windows machine.
5. ~~Whether v1.2.2 runs on his machine / what McAfee's history shows~~ —
   resolved 2026-11-16: Paul's screenshot showed v1.2.1 was actually
   running and waiting at the "Choose a move number" prompt, and his
   McAfee logs cleared the antivirus. v1.2.3 fixes the text-edition
   display that made it look hung.
