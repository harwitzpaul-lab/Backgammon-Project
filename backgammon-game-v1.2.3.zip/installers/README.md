# Backgammon — automatic installers

One command per platform builds a finished, installable package of
the current version (read automatically from `app/pubspec.yaml`).
Everything lands in `dist/` at the project root.

| Platform | Installer | Build command | Must run on |
|---|---|---|---|
| Windows | `Backgammon-Setup-1.2.1.exe` | `powershell -File installers\windows\build_installer.ps1` | Windows + Inno Setup 6 |
| macOS | `Backgammon-1.2.1.pkg` and `.dmg` | `bash installers/macos/build_installer_macos.sh` | a Mac + Xcode |
| Android | `Backgammon-1.2.1.aab` (Play) and `.apk` (direct) | `bash installers/android/build_installer_android.sh` | Linux / Mac / Windows |
| iOS | `Backgammon-1.2.1.ipa` | `bash installers/ios/build_installer_ios.sh` | a Mac + Xcode |

`bash installers/build_all.sh` builds whichever of these the
machine you're sitting at can build, and says plainly which ones it
skipped and why.

## Or: all four at once, automatically

Push the project to GitHub and either tag a version
(`git tag v1.2.1 && git push --tags`) or press **Run workflow** on
the Actions tab. `.github/workflows/release-installers.yml` then
builds **all four installers on the right machines** (Ubuntu for
Android, Windows for the Setup .exe, macOS runners for the .pkg,
.dmg and iOS build) and, for a tag, attaches them all to a GitHub
Release ready to download.

## The read-only information file

`BACKGAMMON-INFO.txt` (project root) is the game's official
information sheet — version, how a turn works, the difficulty
levels, and the dice-seeding note. The file itself is stored
read-only, and **every installer installs it automatically**:

- **Windows** — the Inno Setup script copies it into the install
  folder next to the program and marks the installed copy
  read-only.
- **macOS** — the .pkg places it in /Applications beside the app
  (read-only permissions preserved); the .dmg shows it beside the
  app for drag-install.
- **Android / iOS** — mobile installers cannot drop loose files
  onto a device, so the same file is bundled *inside* the app
  (declared as an asset in `app/pubspec.yaml`), where it is part
  of the signed app package — inherently not user-editable. It is
  installed and removed together with the app itself.

## What each installer does

- **Windows (.exe)** — Inno Setup installer: installs to Program
  Files per-user (no admin prompt), Start Menu shortcut, optional
  desktop shortcut, and a proper entry in *Apps & features* for
  uninstalling. Set `BACKGAMMON_SIGN_PFX` / `BACKGAMMON_SIGN_PASSWORD`
  before running the script to Authenticode-sign it.
- **macOS (.pkg / .dmg)** — the .pkg installs Backgammon.app into
  /Applications through Apple's installer; the .dmg is the familiar
  drag-the-app-onto-Applications disk image. Set
  `BACKGAMMON_MAC_INSTALLER_ID` (a *Developer ID Installer* identity)
  to sign the .pkg; notarizing with `xcrun notarytool submit` after
  signing is what removes Gatekeeper warnings for downloaded copies.
- **Android (.aab / .apk)** — the .aab is what you upload to Google
  Play (Play then generates and signs the per-device installers);
  the .apk installs directly (`adb install`, or open it on the
  phone and allow the install). Both are built in release mode with
  obfuscation.
- **iOS (.ipa)** — iOS has no downloadable installer file format:
  the .ipa **is** the package, installed via Xcode, Apple
  Configurator, TestFlight or the App Store. The script uses
  `app/ios/ExportOptions.plist`; its `method` is `debugging`
  (install on your own registered devices) — change it to
  `app-store-connect` in that file for TestFlight/App Store uploads.

## Signing keys (needed for the stores, not for your own devices)

- **Android upload key** (one-time):
  `keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
  then put the .jks in `app/android/` and create `app/android/key.properties`:
  ```
  storePassword=<jks password>
  keyPassword=<key password>
  keyAlias=upload
  storeFile=../upload-keystore.jks
  ```
  The build is already wired to use it (and `.gitignore` keeps the
  key and passwords out of source control). Back the .jks up — if
  you lose it, updating the Play listing becomes painful.
- **Apple** — sign in to Xcode with Paul's Apple ID; distribution
  needs the paid Apple Developer Program ($99/yr) for TestFlight and
  the App Store. The GitHub pipeline builds iOS without codesigning
  until certificates are added as repo secrets.
- **Windows** — unsigned installers run fine; Windows shows a
  SmartScreen notice ("More info → Run anyway") until the installer
  is Authenticode-signed with a code-signing certificate.
- Change the app IDs from the template defaults
  (`com.example.backgammon_game` / `com.example.backgammonGame`) to
  Paul's own reverse-domain ID before any store submission.

## Microsoft Store (MSIX) — Paul's chosen Windows route

On 2026-11-15 Paul chose Microsoft Store distribution over buying
a code-signing certificate: the Store re-signs the package, so
Store installs get no SmartScreen "unknown publisher" prompt, and
no certificate is needed. Setup lives in `installers/windows-store/`:

- `build_msix.ps1` — builds the graphical app on Windows and
  packages the unsigned Store MSIX into `dist\` (config:
  `msix_config` in `app/pubspec.yaml`, `store: true`).
- `PARTNER-CENTER-CHECKLIST.md` — the steps only Paul can do
  (free individual developer account, reserve the app name, copy
  the three Product identity values into the config), plus the
  per-release submission flow.

The Inno Setup installer above remains for direct downloads
outside the Store (unsigned unless Paul later adds a certificate
via the BACKGAMMON_SIGN_PFX slot).
