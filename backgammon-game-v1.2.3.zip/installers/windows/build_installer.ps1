# Backgammon — automatic Windows installer build.
#
# Run from anywhere (PowerShell):
#   powershell -ExecutionPolicy Bypass -File installers\windows\build_installer.ps1
#
# Does, in order:
#   1. Reads the version from app\pubspec.yaml
#   2. flutter build windows --release (with obfuscation)
#   3. Compiles installers\windows\backgammon.iss with Inno Setup
#   => dist\Backgammon-Setup-<version>.exe
#
# Requirements: Flutter SDK on PATH; Inno Setup 6
# (https://jrsoftware.org/isdl.php or `winget install JRSoftware.InnoSetup`).
# Optional code signing: set $env:BACKGAMMON_SIGN_PFX to a .pfx path
# and $env:BACKGAMMON_SIGN_PASSWORD to its password, and the finished
# installer (not the app exe) will be Authenticode-signed.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)  # repo root
Set-Location $root

# --- Version -------------------------------------------------------
$pubspec = Get-Content 'app\pubspec.yaml' -Raw
if ($pubspec -notmatch 'version:\s*([0-9]+\.[0-9]+\.[0-9]+)') {
    throw 'Could not read the version from app\pubspec.yaml'
}
$version = $Matches[1]
Write-Host "Building Backgammon $version for Windows..."

# --- Build the app -------------------------------------------------
Set-Location "$root\app"
flutter build windows --release --obfuscate --split-debug-info=build\symbols
if ($LASTEXITCODE -ne 0) { throw 'flutter build windows failed' }
Set-Location $root

# --- Find Inno Setup ----------------------------------------------
$iscc = (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Source
if (-not $iscc) {
    $candidates = @(
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
        "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
    )
    $iscc = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $iscc) {
    throw 'Inno Setup 6 not found. Install it: winget install JRSoftware.InnoSetup'
}

# --- Compile the installer ----------------------------------------
New-Item -ItemType Directory -Force -Path 'dist' | Out-Null
& $iscc "/DMyAppVersion=$version" 'installers\windows\backgammon.iss'
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup compilation failed' }
$setup = "dist\Backgammon-Setup-$version.exe"

# --- Optional signing ----------------------------------------------
if ($env:BACKGAMMON_SIGN_PFX -and $env:BACKGAMMON_SIGN_PASSWORD) {
    $signtool = Get-ChildItem "${env:ProgramFiles(x86)}\Windows Kits\10\bin\*\x64\signtool.exe" |
        Sort-Object FullName | Select-Object -Last 1
    if ($signtool) {
        & $signtool.FullName sign /f $env:BACKGAMMON_SIGN_PFX `
            /p $env:BACKGAMMON_SIGN_PASSWORD `
            /tr http://timestamp.digicert.com /td sha256 /fd sha256 $setup
        if ($LASTEXITCODE -ne 0) { throw 'signtool failed' }
        Write-Host 'Installer signed.'
    } else {
        Write-Warning 'signtool.exe not found; installer left unsigned.'
    }
}

Write-Host "Done: $setup"
