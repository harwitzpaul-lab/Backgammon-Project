; Backgammon — Windows installer definition (Inno Setup 6)
; ------------------------------------------------------------------
; Build it with installers/windows/build_installer.ps1, or by hand:
;   flutter build windows --release --obfuscate --split-debug-info=build\symbols
;   ISCC.exe installers\windows\backgammon.iss
; Produces: dist\Backgammon-Setup-1.2.1.exe
;   * Installs per-user (no admin rights needed)
;   * Start Menu shortcut, optional desktop shortcut
;   * Clean uninstaller, registered in Windows "Apps & features"
; Keep MyAppVersion in step with the version tool
; (engine\tool\bump_version.dart updates the pubspecs; update the
;  define below at the same time, or pass /DMyAppVersion=x.y.z).

#define MyAppName "Backgammon"
#ifndef MyAppVersion
  #define MyAppVersion "1.2.1"
#endif
#define MyAppPublisher "Paul"
#define MyAppExeName "backgammon_game.exe"
#define MyAppSourceDir "..\..\app\build\windows\x64\runner\Release"

[Setup]
AppId={{8F3A9C41-2D7B-4E6A-9C1F-5A2B7D4E8F01}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Backgammon
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\..\dist
OutputBaseFilename=Backgammon-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayName={#MyAppName} {#MyAppVersion}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; \
  GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#MyAppSourceDir}\*"; DestDir: "{app}"; \
  Flags: ignoreversion recursesubdirs createallsubdirs
; The read-only information file: installed next to the program,
; and the installed copy is made read-only too.
Source: "..\..\BACKGAMMON-INFO.txt"; DestDir: "{app}"; \
  Flags: ignoreversion; Attribs: readonly

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; \
  Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; \
  Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; \
  Flags: nowait postinstall skipifsilent
