#!/usr/bin/env bash
# Backgammon — build every installer this machine can build.
#
#   bash installers/build_all.sh
#
# Platform reality, enforced here honestly:
#   Android  — builds on Linux, macOS and Windows.
#   Windows  — builds only on Windows (installers/windows/*.ps1).
#   macOS    — builds only on a Mac (Apple's toolchain rule).
#   iOS      — builds only on a Mac (Apple's toolchain rule).
#
# To have all four built automatically in one go, use the GitHub
# Actions pipeline in .github/workflows/release-installers.yml —
# it runs each platform's script on the right kind of machine.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

case "$(uname -s)" in
  Linux)
    bash installers/android/build_installer_android.sh
    echo "Skipped: Windows / macOS / iOS installers (need Windows / a Mac,"
    echo "or push to GitHub and let the Actions pipeline build all four)."
    ;;
  Darwin)
    bash installers/android/build_installer_android.sh
    bash installers/macos/build_installer_macos.sh
    bash installers/ios/build_installer_ios.sh
    echo "Skipped: Windows installer (needs Windows)."
    ;;
  MINGW*|MSYS*|CYGWIN*)
    echo "On Windows, run:  powershell -ExecutionPolicy Bypass -File installers\\windows\\build_installer.ps1"
    echo "and:              bash installers/android/build_installer_android.sh"
    ;;
  *)
    echo "Unknown host OS; see installers/README.md" ; exit 1 ;;
esac
