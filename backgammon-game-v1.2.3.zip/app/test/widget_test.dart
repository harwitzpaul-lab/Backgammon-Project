// Widget tests for Paul's backgammon app: start screen choices,
// the drawn drag-and-drop board, and a game getting under way.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:backgammon_game/main.dart';

void main() {
  testWidgets('Start screen offers difficulty and colour choices',
      (tester) async {
    await tester.pumpWidget(const BackgammonApp());

    expect(find.text('Choose your colour to start.'), findsOneWidget);
    expect(find.text('⚪  White'), findsOneWidget);
    expect(find.text('⚫  Black'), findsOneWidget);
    expect(find.text('Easy'), findsOneWidget);
    expect(find.text('Medium'), findsOneWidget);
    expect(find.text('Hard'), findsOneWidget);
    expect(find.text('v1.2.3+6'), findsOneWidget);
  });

  testWidgets('Hard difficulty can be selected', (tester) async {
    await tester.pumpWidget(const BackgammonApp());
    await tester.tap(find.text('Hard'));
    await tester.pump();
    await tester.tap(find.text('⚪  White'));
    await tester.pump();

    expect(find.textContaining('device: Hard'), findsOneWidget);
  });

  testWidgets('Choosing White starts a game on the drawn board',
      (tester) async {
    await tester.pumpWidget(const BackgammonApp());
    await tester.tap(find.text('⚪  White'));
    await tester.pump();

    // The drawn board with its bar, borne-off trays and pips line.
    expect(find.byKey(const Key('game-board')), findsOneWidget);
    expect(find.text('OFF'), findsNWidgets(2));
    expect(find.textContaining('Borne off'), findsOneWidget);
    expect(find.textContaining('Games played'), findsOneWidget);
    // Point numbers run 1..24 around the board.
    expect(find.text('24'), findsOneWidget);
    expect(find.text('13'), findsOneWidget);
  });
}
