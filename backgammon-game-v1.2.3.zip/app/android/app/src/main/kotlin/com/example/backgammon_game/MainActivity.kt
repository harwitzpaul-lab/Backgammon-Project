package com.example.backgammon_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
