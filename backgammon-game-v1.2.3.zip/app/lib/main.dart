// Backgammon — Paul's game for Android, iOS, Windows and macOS.
//
// One Flutter/Dart codebase builds all four versions. The rules,
// dice, scoring and computer opponent all live in the shared
// `backgammon_engine` package (../engine); this file is the screen.
// There is deliberately NO doubling cube anywhere in this app.
//
// The board (v1.2.0) is a drawn board with real checkers: on your
// turn you drag a checker to its destination (legal destinations
// light up), or tap a checker and then tap where it goes. Moves
// are committed one at a time through the engine's TurnBuilder,
// which filters every step against the surviving legal plays —
// so a drag can never start a move the rules would forbid
// finishing. An Undo button takes back a move within the turn.
//
// Dice: every roll is seeded with the device clock-time and, when a
// location fix is available and permitted, the GPS coordinates —
// mixed with the operating system's secure random source so the
// dice cannot be predicted from the time and place alone. When no
// fix is available the roll falls back automatically (see the
// engine's dice.dart for the exact chain).

import 'dart:math' as math;

import 'package:backgammon_engine/backgammon_engine.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() => runApp(const BackgammonApp());

class BackgammonApp extends StatelessWidget {
  const BackgammonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Backgammon',
      theme: ThemeData(colorSchemeSeed: Colors.brown, useMaterial3: true),
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  var _difficulty = Difficulty.medium;
  ComputerPlayer get _ai => ComputerPlayer(difficulty: _difficulty);
  var _match = Match(targetPoints: 5);

  Board _board = Board.initial();
  Checker? _human; // chosen on the start screen
  Checker _turn = Checker.white;
  List<int>? _dice;
  TurnBuilder? _tb; // live during the human's turn only
  int? _selected; // tap-to-move: point index or barFrom
  bool _noMovesDialogOpen = false; // the "No further moves" alert
  String _status = 'Choose your colour to start.';
  GpsFix? _lastFix;

  DiceRoller get _roller => DiceRoller(gpsProvider: () => _lastFix);

  bool get _interactive =>
      _human != null &&
      _turn == _human &&
      _tb != null &&
      !_tb!.isComplete &&
      !_board.isGameOver;

  @override
  void initState() {
    super.initState();
    _refreshGps();
  }

  /// Best-effort GPS fix for the dice seed. Denied permission, no
  /// satellite fix, and desktop machines without GPS are all normal:
  /// the roller simply falls back for that roll.
  Future<void> _refreshGps() async {
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.low),
      );
      if (mounted) {
        setState(() => _lastFix = GpsFix(pos.latitude, pos.longitude));
      }
    } catch (_) {
      // No fix this time; the dice fallback covers it.
    }
  }

  void _startGame(Checker human) {
    if (_match.isOver) _match = Match(targetPoints: 5);
    _refreshGps();
    final board = Board.initial();
    // Opening roll-off: higher single die opens, playing both numbers.
    var w = _roller.rollSingle();
    var b = _roller.rollSingle();
    while (w == b) {
      w = _roller.rollSingle();
      b = _roller.rollSingle();
    }
    setState(() {
      _human = human;
      _board = board;
      _turn = w > b ? Checker.white : Checker.black;
      _dice = [w, b];
      _tb = null;
      _selected = null;
      _status = 'Opening roll: White $w, Black $b — '
          '${_turn.label} opens (device: ${_difficulty.label}). '
          '${_turnPrompt()}';
    });
    _prepareTurn();
  }

  String _turnPrompt() => _turn == _human
      ? 'Your turn: drag a checker to a lit point, or tap a checker '
          'then tap its destination.'
      : "Device's turn: tap 'Play device turn'.";

  void _prepareTurn() {
    if (_board.isGameOver) {
      _finishGame();
      return;
    }
    if (_turn == _human && _dice != null) {
      final tb = TurnBuilder(_board, _turn, _dice!);
      setState(() {
        _tb = tb;
        if (tb.isComplete) {
          _status = 'No further moves available.';
        }
      });
      if (tb.isComplete) _showNoMovesDialog();
    }
  }

  /// Paul's requested alert (v1.2.2): when the human's roll
  /// leaves no legal move, the game stops on a dialog saying
  /// "No further moves available". The device's turn begins
  /// only after the player acknowledges it with the OK button.
  void _showNoMovesDialog() {
    if (_noMovesDialogOpen) return;
    _noMovesDialogOpen = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        _noMovesDialogOpen = false;
        return;
      }
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Backgammon'),
          content: const Text('No further moves available'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      ).then((_) {
        _noMovesDialogOpen = false;
        if (mounted &&
            _turn == _human &&
            _tb != null &&
            _tb!.isComplete &&
            !_board.isGameOver) {
          _endTurn();
        }
      });
    });
  }

  /// One drag (or tap-tap) move. Returns true when the engine's
  /// turn builder accepted it.
  bool _attemptMove(int from, int to) {
    final tb = _tb;
    if (tb == null || !_interactive) return false;
    if (!tb.playFromTo(from, to)) return false;
    setState(() {
      _board = tb.board;
      _selected = null;
    });
    if (_board.isGameOver || tb.isComplete) {
      final playedText = tb.played.isEmpty
          ? ''
          : 'You played: '
              '${tb.played.map((m) => m.describe(_turn)).join(', ')}. ';
      _endTurn(prefix: playedText);
    }
    return true;
  }

  void _onPointTap(int idx) {
    if (!_interactive) return;
    final sel = _selected;
    if (sel != null && sel != idx && _attemptMove(sel, idx)) return;
    setState(() {
      final movable = _tb!.movableSources.contains(idx);
      _selected = movable ? (sel == idx ? null : idx) : null;
    });
  }

  void _undoMove() {
    final tb = _tb;
    if (tb == null) return;
    if (tb.undo()) {
      setState(() {
        _board = tb.board;
        _selected = null;
      });
    }
  }

  void _playDevice() {
    final dice = _dice;
    if (dice == null) return;
    final sequence = _ai.choose(_board, _turn, dice);
    var board = _board;
    for (final m in sequence) {
      board = board.after(m, _turn);
    }
    setState(() {
      _board = board;
      _status = sequence.isEmpty
          ? 'The device had no legal move.'
          : 'Device played: '
              '${sequence.map((m) => m.describe(_turn)).join(', ')}';
    });
    _endTurn();
  }

  void _passTurn() => _endTurn();

  void _endTurn({String prefix = ''}) {
    _tb = null;
    _selected = null;
    if (_board.isGameOver) {
      _finishGame();
      return;
    }
    final roll = _roller.rollPair();
    setState(() {
      _turn = _turn.opponent;
      _dice = roll.values;
      _status = '$prefix${_turn.label} rolled ${roll.die1}-${roll.die2} '
          '(seed: ${roll.seedSource}). ${_turnPrompt()}';
    });
    _prepareTurn();
  }

  void _finishGame() {
    final winner = _board.winner!;
    final points = _board.gamePoints(winner);
    _match.recordGame(winner, _human!, points);
    setState(() {
      _status = '${winner.label} wins this game for $points point(s). '
          '${_match.summary(_human!)}';
      _tb = null;
      _selected = null;
      _dice = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Backgammon'),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Text('v${AppVersion.display}'),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(_status, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(_human == null
                  ? 'Match: first to ${_match.targetPoints} points. '
                      'Single 1, gammon 2, backgammon 3. No doubling cube.'
                  : _match.summary(_human!)),
              const SizedBox(height: 8),
              if (_human == null)
                _startControls()
              else ...[
                if (_dice != null) _diceRow(),
                Expanded(child: _boardArea()),
                const SizedBox(height: 6),
                Text('Borne off — White: ${_board.whiteOff}, '
                    'Black: ${_board.blackOff}    '
                    'Pips — White: ${_board.pipCount(Checker.white)}, '
                    'Black: ${_board.pipCount(Checker.black)}'),
                const SizedBox(height: 8),
                _actionRow(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _startControls() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('Device difficulty:'),
        const SizedBox(height: 8),
        SegmentedButton<Difficulty>(
          segments: const [
            ButtonSegment(value: Difficulty.easy, label: Text('Easy')),
            ButtonSegment(value: Difficulty.medium, label: Text('Medium')),
            ButtonSegment(value: Difficulty.hard, label: Text('Hard')),
          ],
          selected: {_difficulty},
          onSelectionChanged: (selection) =>
              setState(() => _difficulty = selection.first),
        ),
        const SizedBox(height: 16),
        const Text('Play as:'),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => _startGame(Checker.white),
                child: const Text('⚪  White'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton(
                onPressed: () => _startGame(Checker.black),
                child: const Text('⚫  Black'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        // Copyright and distribution notices, shown on the
        // opening screen (Paul's wording, v1.2.2).
        const Text('© Paul Harwitz',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w600)),
        const Text('Authorized for totally free distribution and use only.',
            textAlign: TextAlign.center),
        const Text('All Rights Reserved.', textAlign: TextAlign.center),
        const Text('Tous Droits Réservés.', textAlign: TextAlign.center),
        const Text('Alle Rechte vorbehalten.',
            textAlign: TextAlign.center),
      ],
    );
  }

  Widget _diceRow() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Text('${_turn.label} to move:  ',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          for (final d in _dice!)
            Container(
              width: 32,
              height: 32,
              margin: const EdgeInsets.only(right: 6),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.brown.shade700),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('$d',
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          if (_tb != null && _turn == _human && !_board.isGameOver)
            Text(_tb!.isComplete
                ? ''
                : 'Move ${_tb!.played.length + 1} of ${_tb!.totalMoves}'),
        ],
      ),
    );
  }

  Widget _boardArea() {
    return _GameBoard(
      board: _board,
      human: _human!,
      interactive: _interactive,
      movableSources: _tb?.movableSources ?? const {},
      targetsFrom: (from) => _tb?.targetsFrom(from) ?? const {},
      selectedSource: _selected,
      onAttempt: _attemptMove,
      onPointTap: _onPointTap,
      onBarTap: () => _onPointTap(barFrom),
      onOffTap: () {
        final sel = _selected;
        if (sel != null) _attemptMove(sel, offTo);
      },
    );
  }

  Widget _actionRow() {
    return Row(
      children: [
        if (!_board.isGameOver && _turn != _human)
          Expanded(
            child: ElevatedButton(
              onPressed: _playDevice,
              child: const Text('Play device turn'),
            ),
          ),
        if (!_board.isGameOver &&
            _turn == _human &&
            _tb != null &&
            _tb!.isComplete)
          Expanded(
            child: ElevatedButton(
              onPressed: _passTurn,
              child: const Text('Pass turn'),
            ),
          ),
        if (_interactive && _tb!.played.isNotEmpty)
          Expanded(
            child: OutlinedButton(
              onPressed: _undoMove,
              child: const Text('Undo move'),
            ),
          ),
        if (_board.isGameOver || _match.isOver)
          Expanded(
            child: ElevatedButton(
              onPressed: () => _startGame(_human!),
              child: const Text('New game'),
            ),
          ),
      ],
    );
  }
}

/// The drawn board: triangular points, round checkers, a centre
/// bar and borne-off trays. Checkers belonging to the human are
/// draggable on their turn when the engine says they can move;
/// every point (and the borne-off tray) is a drop target that
/// accepts only drops the rules allow from that checker.
class _GameBoard extends StatelessWidget {
  final Board board;
  final Checker human;
  final bool interactive;
  final Set<int> movableSources;
  final Set<int> Function(int from) targetsFrom;
  final int? selectedSource;
  final bool Function(int from, int to) onAttempt;
  final void Function(int idx) onPointTap;
  final VoidCallback onBarTap;
  final VoidCallback onOffTap;

  const _GameBoard({
    required this.board,
    required this.human,
    required this.interactive,
    required this.movableSources,
    required this.targetsFrom,
    required this.selectedSource,
    required this.onAttempt,
    required this.onPointTap,
    required this.onBarTap,
    required this.onOffTap,
  });

  static const _felt = Color(0xFF2E5D3A);
  static const _frame = Color(0xFF4E342E);
  static const _lightPoint = Color(0xFFE9D2A4);
  static const _darkPoint = Color(0xFFB56A32);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const barW = 34.0;
        const offW = 42.0;
        final pointW =
            (constraints.maxWidth - barW - offW - 24) / 12; // frame padding
        final d = math.min(42.0, pointW - 3);
        final pointH = math.min(constraints.maxHeight / 2 - 14, d * 5.3);
        return Container(
          key: const Key('game-board'),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _frame,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    _half([12, 13, 14, 15, 16, 17], true, d, pointH),
                    const SizedBox(height: 8),
                    _half([11, 10, 9, 8, 7, 6], false, d, pointH),
                  ],
                ),
              ),
              SizedBox(width: barW, child: _bar(pointH * 2 + 8, d)),
              Expanded(
                child: Column(
                  children: [
                    _half([18, 19, 20, 21, 22, 23], true, d, pointH),
                    const SizedBox(height: 8),
                    _half([5, 4, 3, 2, 1, 0], false, d, pointH),
                  ],
                ),
              ),
              SizedBox(width: offW, child: _offTrays(pointH * 2 + 8, d)),
            ],
          ),
        );
      },
    );
  }

  Widget _half(List<int> indexes, bool top, double d, double pointH) {
    return Row(
      children: [
        for (final i in indexes)
          Expanded(child: _point(i, top, d, pointH)),
      ],
    );
  }

  Widget _point(int idx, bool top, double d, double pointH) {
    final v = board.points[idx];
    final n = v.abs();
    final owner = v > 0 ? Checker.white : Checker.black;
    final isTarget = selectedSource != null &&
        targetsFrom(selectedSource!).contains(idx);
    final canDragTop = interactive &&
        n > 0 &&
        owner == human &&
        movableSources.contains(idx);
    return DragTarget<int>(
      onWillAcceptWithDetails: (details) =>
          interactive && targetsFrom(details.data).contains(idx),
      onAcceptWithDetails: (details) => onAttempt(details.data, idx),
      builder: (context, candidate, rejected) {
        final dropLit = candidate.isNotEmpty &&
            targetsFrom(candidate.first!).contains(idx);
        return GestureDetector(
          onTap: () => onPointTap(idx),
          child: SizedBox(
            height: pointH,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: _PointPainter(
                      pointsDown: top,
                      color: idx.isEven ? _lightPoint : _darkPoint,
                      highlight: isTarget || dropLit,
                      selected: selectedSource == idx,
                    ),
                  ),
                ),
                // Point number, at the tip end of the triangle.
                Positioned(
                  top: top ? null : 1,
                  bottom: top ? 1 : null,
                  child: Text('${idx + 1}',
                      style: const TextStyle(
                          fontSize: 9, color: Colors.white70)),
                ),
                for (var k = 0; k < math.min(n, 5); k++)
                  Positioned(
                    top: top ? k * d * (n > 5 ? 0.8 : 1.0) + 2 : null,
                    bottom: top ? null : k * d * (n > 5 ? 0.8 : 1.0) + 2,
                    child: (k == math.min(n, 5) - 1 && canDragTop)
                        ? _draggableChecker(idx, owner, d,
                            badge: n > 5 ? '$n' : null)
                        : _checker(owner, d,
                            badge: (n > 5 && k == math.min(n, 5) - 1)
                                ? '$n'
                                : null),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _draggableChecker(int source, Checker owner, double d,
      {String? badge}) {
    final chip = _checker(owner, d, badge: badge);
    return Draggable<int>(
      data: source,
      dragAnchorStrategy: pointerDragAnchorStrategy,
      feedback: Material(
        color: Colors.transparent,
        child: _checker(owner, d, badge: badge, shadow: true),
      ),
      childWhenDragging: Opacity(opacity: 0.35, child: chip),
      child: chip,
    );
  }

  Widget _checker(Checker owner, double d,
      {String? badge, bool shadow = false}) {
    final white = owner == Checker.white;
    return Container(
      width: d,
      height: d,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: white ? const Color(0xFFF8F4E6) : const Color(0xFF241F1C),
        border: Border.all(
            color: white ? Colors.black54 : Colors.white38, width: 1.6),
        boxShadow: shadow
            ? const [BoxShadow(color: Colors.black45, blurRadius: 6)]
            : null,
      ),
      child: Container(
        width: d * 0.58,
        height: d * 0.58,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
              color: white ? Colors.black26 : Colors.white24, width: 1.2),
        ),
        child: badge == null
            ? null
            : Text(badge,
                style: TextStyle(
                    fontSize: d * 0.34,
                    fontWeight: FontWeight.bold,
                    color: white ? Colors.black87 : Colors.white)),
      ),
    );
  }

  Widget _bar(double height, double d) {
    Widget side(Checker c, bool topHalf) {
      final n = board.barFor(c);
      final canDrag =
          interactive && c == human && movableSources.contains(barFrom);
      return Expanded(
        child: Container(
          width: double.infinity,
          color: _felt.withValues(alpha: 0.35),
          child: Stack(
            alignment: Alignment.center,
            children: [
              for (var k = 0; k < math.min(n, 4); k++)
                Positioned(
                  top: topHalf ? k * d * 0.8 + 2 : null,
                  bottom: topHalf ? null : k * d * 0.8 + 2,
                  child: (k == math.min(n, 4) - 1 && canDrag)
                      ? _draggableChecker(barFrom, c, d * 0.92)
                      : _checker(c, d * 0.92),
                ),
            ],
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: onBarTap,
      child: SizedBox(
        height: height,
        child: Column(
          children: [side(Checker.black, true), side(Checker.white, false)],
        ),
      ),
    );
  }

  Widget _offTrays(double height, double d) {
    Widget tray(Checker c) {
      final n = board.offFor(c);
      final mine = c == human;
      return Expanded(
        child: DragTarget<int>(
          onWillAcceptWithDetails: (details) =>
              interactive && mine && targetsFrom(details.data).contains(offTo),
          onAcceptWithDetails: (details) => onAttempt(details.data, offTo),
          builder: (context, candidate, rejected) {
            final lit = candidate.isNotEmpty &&
                mine &&
                targetsFrom(candidate.first!).contains(offTo);
            return GestureDetector(
              onTap: mine ? onOffTap : null,
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.only(left: 4),
                decoration: BoxDecoration(
                  color: lit ? Colors.green.shade700 : _felt.withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                      color: selectedSource != null &&
                              mine &&
                              targetsFrom(selectedSource!).contains(offTo)
                          ? Colors.greenAccent
                          : Colors.transparent,
                      width: 1.6),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('OFF',
                        style: TextStyle(
                            fontSize: 9,
                            color: Colors.white70,
                            letterSpacing: 1)),
                    if (n > 0) _checker(c, d * 0.8),
                    Text('$n',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            );
          },
        ),
      );
    }

    return SizedBox(
      height: height,
      child: Column(children: [tray(Checker.black), tray(Checker.white)]),
    );
  }
}

/// One triangular point. [pointsDown] for the top row.
class _PointPainter extends CustomPainter {
  final bool pointsDown;
  final Color color;
  final bool highlight;
  final bool selected;

  const _PointPainter({
    required this.pointsDown,
    required this.color,
    required this.highlight,
    required this.selected,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path();
    if (pointsDown) {
      path
        ..moveTo(1, 0)
        ..lineTo(size.width - 1, 0)
        ..lineTo(size.width / 2, size.height);
    } else {
      path
        ..moveTo(1, size.height)
        ..lineTo(size.width - 1, size.height)
        ..lineTo(size.width / 2, 0);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = color);
    if (highlight || selected) {
      canvas.drawPath(
        path,
        Paint()
          ..color = selected ? Colors.amber : Colors.greenAccent
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4,
      );
    }
  }

  @override
  bool shouldRepaint(_PointPainter old) =>
      pointsDown != old.pointsDown ||
      color != old.color ||
      highlight != old.highlight ||
      selected != old.selected;
}
